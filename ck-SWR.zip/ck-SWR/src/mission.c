/*
 *                    Celestial Knights
 *                  Benjamin 'Tzu' Peters
 *                       mission.c
 *   Module for mission data that allows historic fights
 */

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "mud.h"

MISSION_DATA *first_mission;
MISSION_DATA *last_mission;

/* local routines */
void fread_mission args( ( MISSION_DATA * mission, FILE * fp ) );
bool load_mission_file args( ( char *missionfile ) );
void write_mission_list args( ( void ) );
int mission_id args( ( int mid ) );
void restat_mission args( ( MISSION_DATA * mission, CHAR_DATA * victim, int x ) );

char *const mission_goals[] = {
   "none", "time", "hp", "mob", "r4", "r5", "r6", "r7", "r8",
   "r9", "r10", "r11", "r12", "r13", "r14", "r15", "r16", "r17",
   "r18", "r19", "r20", "r21", "r22", "r23", "r24",
   "r25", "r26", "r27", "r28", "r29", "r30", "r31"
};

void apply_skills( CHAR_DATA * victim )
{
  if ( victim->top_level >= 25 )
    SET_BIT( victim->defenses, DFND_DODGE );

  if ( victim->top_level >= 50 )
   {
    SET_BIT( victim->defenses, DFND_PARRY );
    victim->numattacks++;
    victim->damroll += 20;
   }

  if ( victim->top_level >= 75 )
   {
    victim->numattacks++;
    victim->damroll += 40;
   }

  if ( victim->top_level >= 95 )
   {
    SET_BIT( victim->affected_by, AFF_SANCTUARY );
    victim->numattacks++;
    victim->damroll += 60;
   }

    victim->perm_str = 15;
    victim->perm_con = 15;
    victim->perm_dex = 15;
  return;  
}

void restat_target( MISSION_DATA * mission, CHAR_DATA * victim )
{  
   int value = mission->level[0];
   victim->powerlevel = mission->power[0];
   victim->race = mission->race[0];
   victim->max_hit = mission->max_hit[0];   
   SET_BIT( victim->exact, EX_MTARGET );

   STRFREE( victim->name );
   victim->name = STRALLOC( mission->mob_name[0] );
   STRFREE( victim->short_descr );
   victim->short_descr = STRALLOC( mission->short_descr[0] );
   STRFREE( victim->long_descr );
   victim->long_descr = STRALLOC( mission->long_descr[0]);
   
   victim->top_level = value;
   victim->armor = LEVEL_HERO - value * 2.5;
   victim->hitroll = value/5;
   victim->damroll = 20;
   victim->damplus = ( value / 2 );
   victim->gold = ( value * 25 ) * 2;   
   victim->hit = victim->max_hit;

   victim->max_mana = 100 + ( value*50 );
   victim->mana = victim->max_mana;

   victim->base_pl = victim->powerlevel;
   apply_skills( victim );
  return;
}

void restat_mission( MISSION_DATA * mission, CHAR_DATA * victim, int x )
{  
   int g;
   int value = mission->level[x];
   victim->powerlevel = mission->power[x];
   victim->race = mission->race[x];
   victim->max_hit = mission->max_hit[x];   

   for ( g = 0; g < MAX_GOALS; g++ )
     if ( mission->goal_type[g] )
      if ( mission->goal_type[g] == GOAL_MOB )
       if ( mission->goal[g] == x )
        SET_BIT( victim->exact, EX_MGOAL );

   STRFREE( victim->name );
   victim->name = STRALLOC( mission->mob_name[x] );
   STRFREE( victim->short_descr );
   victim->short_descr = STRALLOC( mission->short_descr[x] );
   STRFREE( victim->long_descr );
   victim->long_descr = STRALLOC( mission->long_descr[x]);
   
   victim->top_level = value;
   victim->armor = LEVEL_HERO - value * 2.5;
   victim->hitroll = value/5;
   victim->damroll = 20;
   victim->damplus = ( value / 2 );
   victim->gold = ( value * 25 );   
   
   victim->hit = victim->max_hit;

   victim->max_mana = 100 + ( value*50 );
   victim->mana = victim->max_mana;

   victim->base_pl = victim->powerlevel;
   apply_skills( victim );

  return;
}

/* Find an empty zone to play */
bool check_mission_1( CHAR_DATA *ch )
{
   CHAR_DATA * rch, * rch_next;
   ROOM_INDEX_DATA *room;
   int vnum;
   int lrange = ROOM_M1_LO;
   int trange = ROOM_M1_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;
         if ( !IS_NPC( rch ) )
           return FALSE;   
      }
   }

return TRUE;
}

/* If prequiste for target to appear check if other mobs dead */
bool ready_target_1( CHAR_DATA *ch, CHAR_DATA * victim )
{
   CHAR_DATA * rch, * rch_next;
   ROOM_INDEX_DATA *room;
   int vnum;
   int lrange = ROOM_M1_LO;
   int trange = ROOM_M1_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;

         if ( rch == victim )
          continue;

         if ( IS_NPC( rch ) && IS_MISSION( rch ) )
           return FALSE;   
      }
   }

return TRUE;
}

/* For mob goal, make sure other baddies still alive */
bool check_goal_1( MISSION_DATA *mission, CHAR_DATA * victim, int npc )
{
   CHAR_DATA * rch, * rch_next;
   ROOM_INDEX_DATA *room;
   int vnum, count = 0;
   int lrange = ROOM_M1_LO;
   int trange = ROOM_M1_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;

         if ( IS_NPC( rch ) && rch != victim )
          count++;
      }
   }

  if ( count < ( npc - 1 ) )
   return FALSE;

 return TRUE;
}

/* Clean zone for play */
void clean_mission_1( void )
{
   CHAR_DATA * rch, * rch_next;
   OBJ_DATA * obj, * obj_next;
   ROOM_INDEX_DATA *room;
   int vnum;
   int lrange = ROOM_M1_LO;
   int trange = ROOM_M1_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;
         if ( IS_NPC( rch ) )
          extract_char( rch, TRUE );
      }
      for( obj = room->first_content; obj; obj = obj_next )
      {
          obj_next = obj->next_content;
          extract_obj( obj );
      }   
   }
 return;
}

/* Find an empty zone to play */
bool check_mission_2( CHAR_DATA *ch )
{
   CHAR_DATA * rch, * rch_next;
   ROOM_INDEX_DATA *room;
   int vnum;
   int lrange = ROOM_M2_LO;
   int trange = ROOM_M2_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;
         if ( !IS_NPC( rch ) )
           return FALSE;   
      }
   }

return TRUE;
}

/* If preq for target to appear check if other mobs dead */
bool ready_target_2( CHAR_DATA *ch, CHAR_DATA * victim )
{
   CHAR_DATA * rch, * rch_next;
   ROOM_INDEX_DATA *room;
   int vnum;
   int lrange = ROOM_M2_LO;
   int trange = ROOM_M2_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;

         if ( rch == victim )
          continue;

         if ( IS_NPC( rch ) && IS_MISSION( rch ) )
           return FALSE;   
      }
   }

return TRUE;
}

/* For mob goal, make sure other baddies still alive */
bool check_goal_2( MISSION_DATA *mission, CHAR_DATA * victim, int npc )
{
   CHAR_DATA * rch, * rch_next;
   ROOM_INDEX_DATA *room;
   int vnum, count = 0;
   int lrange = ROOM_M2_LO;
   int trange = ROOM_M2_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;

         if ( IS_NPC( rch ) && rch != victim )
          count++;
      }
   }

  if ( count < ( npc - 1 ) )
   return FALSE;

 return TRUE;
}

/* Clean zone for play */
void clean_mission_2( void )
{
   CHAR_DATA * rch, * rch_next;
   OBJ_DATA * obj, * obj_next;
   ROOM_INDEX_DATA *room;
   int vnum;
   int lrange = ROOM_M2_LO;
   int trange = ROOM_M2_HI;

   for( vnum = lrange; vnum <= trange; vnum++ )
   {
     /* Forgot to make a area dummy */
      if( ( room = get_room_index( vnum ) ) == NULL )
       continue;
      
      for( rch = room->first_person; rch; rch = rch_next )
      {
         rch_next = rch->next_in_room;
         if ( IS_NPC( rch ) )
          extract_char( rch, TRUE );
      }
      for( obj = room->first_content; obj; obj = obj_next )
      {
          obj_next = obj->next_content;
          extract_obj( obj );
      }   
   }
 return;
}

int get_mission_goals( char *flag )
{
   int x;

   for( x = 0; x < MAX_GTYPES; x++ )
      if( !str_cmp( flag, mission_goals[x] ) )
         return x;
   return -1;
}

MISSION_DATA *get_mission( char *name )
{
   MISSION_DATA *mission;

   for( mission = first_mission; mission; mission = mission->next )
      if( !str_cmp( name, mission->name ) )
         return mission;
   return NULL;
}

MISSION_DATA *get_mission_id( int id )
{
   MISSION_DATA *mission;

   for( mission = first_mission; mission; mission = mission->next )
      if( id == mission->id )
         return mission;
   return NULL;
}

void write_mission_list(  )
{
   MISSION_DATA *tmission;
   FILE *fpout;
   char filename[256];

   sprintf( filename, "%s%s", MISSION_DIR, MISSION_LIST );
   fpout = fopen( filename, "w" );
   if( !fpout )
   {
      bug( "FATAL: cannot open mission.lst for writing!\r\n", 0 );
      return;
   }
   for( tmission = first_mission; tmission; tmission = tmission->next )
      fprintf( fpout, "%s\n", tmission->filename );
   fprintf( fpout, "$\n" );
   fclose( fpout );
}

void save_mission( MISSION_DATA * mission )
{
   FILE *fp;
   char filename[256];
   int x;

   if( !mission )
   {
      bug( "save_mission: null mission pointer!", 0 );
      return;
   }

   if( !mission->filename || mission->filename[0] == '\0' )
   {
      bug( "save_mission: %s has no filename", mission->name );
      return;
   }

   sprintf( filename, "%s%s", MISSION_DIR, mission->filename );

   if( ( fp = fopen( filename, "w" ) ) == NULL )
   {
      bug( "save_mission: fopen", 0 );
      perror( filename );
   }
   else
   {

      fprintf( fp, "#MISSION\n" );
      fprintf( fp, "Name         %s~\n", mission->name );
      fprintf( fp, "Filename     %s~\n", mission->filename );
      fprintf( fp, "MissionID    %d\n", mission->id );
      fprintf( fp, "Reward       %d\n", mission->reward );
      fprintf( fp, "Ready       %d\n", mission->ready );

      fprintf( fp, "Power        ");
      for ( x = 0; x < MMOB; x++ )
        fprintf( fp, "%llu ", mission->power[x] );
      fprintf( fp, "\n");

      fprintf( fp, "MobName      %s~\n", mission->mob_name[0] );
      fprintf( fp, "MobShort     %s~\n", mission->short_descr[0] );
      fprintf( fp, "MobLong      %s~\n", mission->long_descr[0] );

     if ( mission->mob_name[1] )
      {
       fprintf( fp, "MobName_1    %s~\n", mission->mob_name[1] );
       fprintf( fp, "MobShort_1   %s~\n", mission->short_descr[1] );
       fprintf( fp, "MobLong_1    %s~\n", mission->long_descr[1] );
      }

     if ( mission->mob_name[2] )
      {
       fprintf( fp, "MobName_2    %s~\n", mission->mob_name[2] );
       fprintf( fp, "MobShort_2   %s~\n", mission->short_descr[2] );
       fprintf( fp, "MobLong_2    %s~\n", mission->long_descr[2] );
      }

     if ( mission->mob_name[3] )
      {
       fprintf( fp, "MobName_3    %s~\n", mission->mob_name[3] );
       fprintf( fp, "MobShort_3   %s~\n", mission->short_descr[3] );
       fprintf( fp, "MobLong_3    %s~\n", mission->long_descr[3] );
      }

     if ( mission->mob_name[4] )
      {
       fprintf( fp, "MobName_4    %s~\n", mission->mob_name[4] );
       fprintf( fp, "MobShort_4   %s~\n", mission->short_descr[4] );
       fprintf( fp, "MobLong_4    %s~\n", mission->long_descr[4] );
      }


     if ( mission->mob_name[5] )
      {
       fprintf( fp, "MobName_5    %s~\n", mission->mob_name[5] );
       fprintf( fp, "MobShort_5   %s~\n", mission->short_descr[5] );
       fprintf( fp, "MobLong_5    %s~\n", mission->long_descr[5] );
      }


     if ( mission->mob_name[6] )
      {
       fprintf( fp, "MobName_6    %s~\n", mission->mob_name[6] );
       fprintf( fp, "MobShort_6   %s~\n", mission->short_descr[6] );
       fprintf( fp, "MobLong_6    %s~\n", mission->long_descr[6] );
      }


     if ( mission->mob_name[7] )
      {
       fprintf( fp, "MobName_7    %s~\n", mission->mob_name[7] );
       fprintf( fp, "MobShort_7   %s~\n", mission->short_descr[7] );
       fprintf( fp, "MobLong_7    %s~\n", mission->long_descr[7] );
      }


     if ( mission->mob_name[8] )
      {
       fprintf( fp, "MobName_8    %s~\n", mission->mob_name[8] );
       fprintf( fp, "MobShort_8   %s~\n", mission->short_descr[8] );
       fprintf( fp, "MobLong_8    %s~\n", mission->long_descr[8] );
      }


     if ( mission->mob_name[9] )
      {
       fprintf( fp, "MobName_9    %s~\n", mission->mob_name[9] );
       fprintf( fp, "MobShort_9   %s~\n", mission->short_descr[9] );
       fprintf( fp, "MobLong_9    %s~\n", mission->long_descr[9] );
      }


      fprintf( fp, "MobRace      ");
      for ( x = 0; x < MMOB; x++ )
        fprintf( fp, "%d ", mission->race[x] );
      fprintf( fp, "\n");

      fprintf( fp, "MobLevel     ");
      for ( x = 0; x < MMOB; x++ )
        fprintf( fp, "%d ", mission->level[x] );
      fprintf( fp, "\n");

      fprintf( fp, "MobHP        ");
      for ( x = 0; x < MMOB; x++ )
        fprintf( fp, "%d ", mission->max_hit[x] );
      fprintf( fp, "\n");

      fprintf( fp, "Timer        %d\n", mission->timer );

     if ( mission->goal_type[1] > 0 )
      {
       fprintf( fp, "GoalType_1   %d\n", mission->goal_type[1] );
       fprintf( fp, "Goal_1       %d\n", mission->goal[1] );
      }

     if ( mission->goal_type[1] > 0 )
      {
       fprintf( fp, "GoalType_2   %d\n", mission->goal_type[2] );
       fprintf( fp, "Goal_2       %d\n", mission->goal[2] );
      }

     if ( mission->goal_type[1] > 0 )
      {
       fprintf( fp, "GoalType_3   %d\n", mission->goal_type[3] );
       fprintf( fp, "Goal_3       %d\n", mission->goal[3] );
      }

      fprintf( fp, "End\n\n" );
      fprintf( fp, "#END\n" );
      fclose( fp );
      fp = NULL;
   }
   return;
}

void fread_mission( MISSION_DATA * mission, FILE * fp )
{
   char buf[MAX_STRING_LENGTH];
   char *word;
   bool fMatch;
   int x;


   for( ;; )
   {
      word = feof( fp ) ? "End" : fread_word( fp );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
         case '*':
            fMatch = TRUE;
            fread_to_eol( fp );
            break;

         case 'E':
            if( !str_cmp( word, "End" ) )
            {
               if( !mission->name )
                  mission->name = STRALLOC( "" );
               return;
            }
            break;

         case 'F':
            KEY( "Filename", mission->filename, fread_string_nohash( fp ) );
            break;

         case 'G':
            KEY( "Goal_1", mission->goal[1], fread_number( fp ) );
            KEY( "Goal_2", mission->goal[2], fread_number( fp ) );
            KEY( "Goal_3", mission->goal[3], fread_number( fp ) );
            KEY( "GoalType_1", mission->goal_type[1], fread_number( fp ) );
            KEY( "GoalType_2", mission->goal_type[2], fread_number( fp ) );
            KEY( "GoalType_3", mission->goal_type[3], fread_number( fp ) );
            break;

         case 'M':
            KEY( "MissionID", mission->id, fread_number( fp ) );

           if( !str_cmp( word, "MobHP" ) )
            {
               for( x = 0; x < MMOB; x++ )
                  mission->max_hit[x] = fread_number( fp );
               fread_to_eol( fp );
               fMatch = TRUE;
            }

           if( !str_cmp( word, "MobLevel" ) )
            {
               for( x = 0; x < MMOB; x++ )
                  mission->level[x] = fread_number( fp );
               fread_to_eol( fp );
               fMatch = TRUE;
            }

            KEY( "MobLong", mission->long_descr[0], fread_string( fp ) );
            KEY( "MobLong_1", mission->long_descr[1], fread_string( fp ) );
            KEY( "MobLong_2", mission->long_descr[2], fread_string( fp ) );
            KEY( "MobLong_3", mission->long_descr[3], fread_string( fp ) );
            KEY( "MobLong_4", mission->long_descr[4], fread_string( fp ) );    
            KEY( "MobLong_5", mission->long_descr[5], fread_string( fp ) );
            KEY( "MobLong_6", mission->long_descr[6], fread_string( fp ) );
            KEY( "MobLong_7", mission->long_descr[7], fread_string( fp ) );
            KEY( "MobLong_8", mission->long_descr[8], fread_string( fp ) );
            KEY( "MobLong_9", mission->long_descr[9], fread_string( fp ) );
            KEY( "MobName", mission->mob_name[0], fread_string( fp ) );
            KEY( "MobName_1", mission->mob_name[1], fread_string( fp ) );
            KEY( "MobName_2", mission->mob_name[2], fread_string( fp ) );
            KEY( "MobName_3", mission->mob_name[3], fread_string( fp ) );
            KEY( "MobName_4", mission->mob_name[4], fread_string( fp ) );
            KEY( "MobName_5", mission->mob_name[5], fread_string( fp ) );
            KEY( "MobName_6", mission->mob_name[6], fread_string( fp ) );
            KEY( "MobName_7", mission->mob_name[7], fread_string( fp ) );
            KEY( "MobName_8", mission->mob_name[8], fread_string( fp ) );
            KEY( "MobName_9", mission->mob_name[9], fread_string( fp ) );

           if( !str_cmp( word, "MobRace" ) )
            {
               for( x = 0; x < MMOB; x++ )
                  mission->race[x] = fread_number( fp );
               fread_to_eol( fp );
               fMatch = TRUE;
            }

            KEY( "MobShort", mission->short_descr[0], fread_string( fp ) );
            KEY( "MobShort_1", mission->short_descr[1], fread_string( fp ) );
            KEY( "MobShort_2", mission->short_descr[2], fread_string( fp ) );
            KEY( "MobShort_3", mission->short_descr[3], fread_string( fp ) );
            KEY( "MobShort_4", mission->short_descr[4], fread_string( fp ) );
            KEY( "MobShort_5", mission->short_descr[5], fread_string( fp ) );
            KEY( "MobShort_6", mission->short_descr[6], fread_string( fp ) );
            KEY( "MobShort_7", mission->short_descr[7], fread_string( fp ) );
            KEY( "MobShort_8", mission->short_descr[8], fread_string( fp ) );
            KEY( "MobShort_9", mission->short_descr[9], fread_string( fp ) );
            break;
         
         case 'N':
            KEY( "Name", mission->name, fread_string( fp ) );
            break;

         case 'P':
           if( !str_cmp( word, "Power" ) )
            {
               for( x = 0; x < MMOB; x++ )
                  mission->power[x] = fread_number( fp );
               fread_to_eol( fp );
               fMatch = TRUE;
            }
            break;

         case 'R':
            KEY( "Ready", mission->ready, fread_number( fp ) );
            KEY( "Reward", mission->reward, fread_number( fp ) );
            break;

         case 'T':
            KEY( "Timer", mission->timer, fread_number( fp ) );
            break;
      }

      if( !fMatch )
      {
         sprintf( buf, "Fread_mission: no match: %s", word );
         bug( buf, 0 );
      }
   }
}

bool load_mission_file( char *missionfile )
{
   char filename[256];
   MISSION_DATA *mission;
   FILE *fp;
   bool found;

   CREATE( mission, MISSION_DATA, 1 );

   found = FALSE;
   sprintf( filename, "%s%s", MISSION_DIR, missionfile );

   if( ( fp = fopen( filename, "r" ) ) != NULL )
   {

      found = TRUE;
      for( ;; )
      {
         char letter;
         char *word;

         letter = fread_letter( fp );
         if( letter == '*' )
         {
            fread_to_eol( fp );
            continue;
         }

         if( letter != '#' )
         {
            bug( "Load_mission_file: # not found.", 0 );
            break;
         }

         word = fread_word( fp );
         if( !str_cmp( word, "MISSION" ) )
         {
            fread_mission( mission, fp );
            break;
         }
         else if( !str_cmp( word, "END" ) )
            break;
         else
         {
            char buf[MAX_STRING_LENGTH];

            sprintf( buf, "Load_mission_file: bad section: %s.", word );
            bug( buf, 0 );
            break;
         }
      }
      fclose( fp );
   }

   if( !found )
      DISPOSE( mission );
   else
      LINK( mission, first_mission, last_mission, next, prev );

   return found;
}

void load_missions(  )
{
   FILE *fpList;
   char *filename;
   char missionlist[256];
   char buf[MAX_STRING_LENGTH];

   first_mission = NULL;
   last_mission = NULL;

   log_string( "Loading missions..." );

   sprintf( missionlist, "%s%s", MISSION_DIR, MISSION_LIST );
   if( ( fpList = fopen( missionlist, "r" ) ) == NULL )
   {
      perror( missionlist );
      exit( 1 );
   }

   for( ;; )
   {
      filename = feof( fpList ) ? "$" : fread_word( fpList );
      log_string( filename );
      if( filename[0] == '$' )
         break;

      if( !load_mission_file( filename ) )
      {
         sprintf( buf, "Cannot load mission file: %s", filename );
         bug( buf, 0 );
      }
   }
   fclose( fpList );
   log_string( " Done missions " );
   return;
}

void do_setmission( CHAR_DATA * ch, char *argument )
{
   int mid, type = 0, gvalue = 0, value = 0;
   char arg1[MAX_INPUT_LENGTH];
   char arg2[MAX_INPUT_LENGTH];
   char arg3[MAX_INPUT_LENGTH];
   MISSION_DATA *mission;

   if( IS_NPC( ch ) )
   {
      send_to_char( "Huh?\r\n", ch );
      return;
   }

   argument = one_argument( argument, arg1 );
   argument = one_argument( argument, arg2 );
   argument = one_argument( argument, arg3 );

   if( arg1[0] == '\0' || arg2[0] == '\0' )
   {
      send_to_char( "Usage: setmission <mission id> <field> [value]\r\n", ch );
      send_to_char( "\r\nField being one of:\r\n", ch );
      send_to_char( " name filename id\r\n", ch );
      send_to_char( " goal1 goal2 goal3 reward timer ready\r\n", ch );
      send_to_char( " \r\n", ch );
      send_to_char( " For target mob:\r\n", ch );
      send_to_char( "  mobname short long\r\n", ch );
      send_to_char( "  power level race hp\r\n", ch );
      send_to_char( " For mob #2:\r\n", ch );
      send_to_char( "  mobname2 short2 long2\r\n", ch );
      send_to_char( "  power2 level2 race2 hp2\r\n", ch );
      send_to_char( " For mob #3:\r\n", ch );
      send_to_char( "  mobname3 short3 long3\r\n", ch );
      send_to_char( "  power3 level3 race3 hp3\r\n", ch );
      send_to_char( " For mob #4:\r\n", ch );
      send_to_char( "  mobname4 short4 long4\r\n", ch );
      send_to_char( "  power4 level4 race4 hp4\r\n", ch );
      send_to_char( " For mob #5:\r\n", ch );
      send_to_char( "  mobname5 short5 long5\r\n", ch );
      send_to_char( "  power5 level5 race5 hp5\r\n", ch );
      send_to_char( " For mob #6:\r\n", ch );
      send_to_char( "  mobname6 short6 long6\r\n", ch );
      send_to_char( "  power6 level6 race6 hp6\r\n", ch );
      send_to_char( " For mob #7:\r\n", ch );
      send_to_char( "  mobname7 short7 long7\r\n", ch );
      send_to_char( "  power7 level7 race7 hp7\r\n", ch );
      send_to_char( " For mob #8:\r\n", ch );
      send_to_char( "  mobname8 short8 long8\r\n", ch );
      send_to_char( "  power8 level8 race8 hp8\r\n", ch );
      return;
   }

   mid = atoi( arg1 );
   mission = get_mission_id( mid );
   if( !mission )
   {
      send_to_char( "No such mission.\r\n", ch );
      return;
   }


/* Simple toggle to lock missions out or release them. */
   if( !strcmp( arg2, "ready" ) )
   {
     if ( mission->ready )
      {
       mission->ready = FALSE;
       send_to_char( "Mission is now unavailible to mortals.\r\n", ch );
       save_mission( mission );
       return;
      }

     mission->ready = TRUE;
     send_to_char( "Mission now ready to play.\r\n", ch );
     save_mission( mission );
     return;
   }
  
  if ( arg3[0] == '\0' )
   {
     do_setmission( ch, "" );
     return;
   }

   if( !strcmp( arg2, "name" ) )
   {
      STRFREE( mission->name );
      mission->name = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "filename" ) )
   {
      DISPOSE( mission->filename );
      mission->filename = str_dup( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      write_mission_list(  );
      return;
   }

   if( !strcmp( arg2, "mobname" ) )
   {
      STRFREE( mission->mob_name[0] );
      mission->mob_name[0] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short" ) )
   {
      STRFREE( mission->short_descr[0] );
      mission->short_descr[0] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long" ) )
   {
      STRFREE( mission->long_descr[0] );
      mission->long_descr[0] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power" ) )
   {
      mission->power[0] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "mobname2" ) )
   {
      STRFREE( mission->mob_name[1] );
      mission->mob_name[1] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short2" ) )
   {
      STRFREE( mission->short_descr[1] );
      mission->short_descr[1] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long2" ) )
   {
      STRFREE( mission->long_descr[1] );
      mission->long_descr[1] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power2" ) )
   {
      mission->power[1] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "mobname3" ) )
   {
      STRFREE( mission->mob_name[2] );
      mission->mob_name[2] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short3" ) )
   {
      STRFREE( mission->short_descr[2] );
      mission->short_descr[2] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long3" ) )
   {
      STRFREE( mission->long_descr[2] );
      mission->long_descr[2] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power3" ) )
   {
      mission->power[2] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "mobname4" ) )
   {
      STRFREE( mission->mob_name[3] );
      mission->mob_name[3] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short4" ) )
   {
      STRFREE( mission->short_descr[3] );
      mission->short_descr[3] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long4" ) )
   {
      STRFREE( mission->long_descr[3] );
      mission->long_descr[3] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power4" ) )
   {
      mission->power[3] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "mobname5" ) )
   {
      STRFREE( mission->mob_name[4] );
      mission->mob_name[4] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short5" ) )
   {
      STRFREE( mission->short_descr[4] );
      mission->short_descr[4] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long5" ) )
   {
      STRFREE( mission->long_descr[4] );
      mission->long_descr[4] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power5" ) )
   {
      mission->power[4] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
 
   if( !strcmp( arg2, "level5" ) )
   {
      mission->level[4] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race5" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[4] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp5" ) )
   {
      mission->max_hit[4] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "mobname6" ) )
   {
      STRFREE( mission->mob_name[5] );
      mission->mob_name[5] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short6" ) )
   {
      STRFREE( mission->short_descr[5] );
      mission->short_descr[5] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long6" ) )
   {
      STRFREE( mission->long_descr[5] );
      mission->long_descr[5] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power6" ) )
   {
      mission->power[5] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
 
   if( !strcmp( arg2, "level6" ) )
   {
      mission->level[5] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race6" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[5] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp6" ) )
   {
      mission->max_hit[5] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "mobname7" ) )
   {
      STRFREE( mission->mob_name[6] );
      mission->mob_name[6] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short7" ) )
   {
      STRFREE( mission->short_descr[6] );
      mission->short_descr[6] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long7" ) )
   {
      STRFREE( mission->long_descr[6] );
      mission->long_descr[6] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power7" ) )
   {
      mission->power[6] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
 
   if( !strcmp( arg2, "level7" ) )
   {
      mission->level[6] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race7" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[6] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp7" ) )
   {
      mission->max_hit[6] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "mobname8" ) )
   {
      STRFREE( mission->mob_name[7] );
      mission->mob_name[7] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   
   if( !strcmp( arg2, "short8" ) )
   {
      STRFREE( mission->short_descr[7] );
      mission->short_descr[7] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
    
   if( !strcmp( arg2, "long8" ) )
   {
      STRFREE( mission->long_descr[7] );
      mission->long_descr[7] = STRALLOC( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "power8" ) )
   {
      mission->power[7] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
 
   if( !strcmp( arg2, "level8" ) )
   {
      mission->level[7] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race8" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[7] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp8" ) )
   {
      mission->max_hit[7] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
   

   if( !strcmp( arg2, "reward" ) )
   {
      mission->reward = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "level" ) )
   {
      mission->level[0] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[0] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp" ) )
   {
      mission->max_hit[0] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "level2" ) )
   {
      mission->level[1] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race2" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[1] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp2" ) )
   {
      mission->max_hit[1] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "level3" ) )
   {
      mission->level[2] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race3" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[2] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp3" ) )
   {
      mission->max_hit[2] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "level4" ) )
   {
      mission->level[3] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "race4" ) )
   {
      value = get_npc_race( arg3 );
      if ( value < 0 )
       value = atoi( arg3 );
      if ( value < 0 || value > MAX_NPC_RACE )
       {
        send_to_char("Not a valid race.\r\n", ch );
        return;
       }

      mission->race[3] = value;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "hp4" ) )
   {
      mission->max_hit[3] = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "timer" ) )
   {
      mission->timer = atoi( arg3 );
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }
  
   if( !strcmp( arg2, "goal1" ) )
   {
     if ( arg3[0] == '\0' )
       {
        ch_printf( ch, "Usage: setmission <id> goal1 <type> <value>\r\n");
        return;
       }

      type = get_mission_goals( arg3 );
      if ( type < 0 )
       type = atoi( arg3 );
      if ( type < 0 || type > MAX_GTYPES )
       {
        ch_printf( ch, "Not a valid Mission Goal\r\n");
        return;
       }

     if ( argument[0] == '\0' )
       {
        ch_printf( ch, "Usage: setmission <id> goal1 <type> <value>\r\n");
        return;
       }

     gvalue = atoi( argument );

     if ( type == GOAL_TIME )
      if ( !mission->timer || mission->timer < gvalue )
        {
         ch_printf( ch, "Mission timer must be more then time goal\r\n");
         return;
        }
      
     if ( type == GOAL_HP )
      if ( gvalue < 1 || gvalue > 99 )
        {
         ch_printf( ch, "HP Goal range is 1 - 99 percent.\r\n");
         return;
        }
      
     if ( type == GOAL_MOB )
      if ( gvalue < 1 || gvalue > ( MMOB - 2 ) )
        {
         ch_printf( ch, "Which mob should they kill first? 1 - %d.\r\n", ( MMOB - 2 ) );
         return;
        }
      
      mission->goal_type[1] = type;
      mission->goal[1] = gvalue;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "goal2" ) )
   {
     if ( arg3[0] == '\0' )
       {
        ch_printf( ch, "Usage: setmission <id> goal2 <type> <value>\r\n");
        return;
       }

      type = get_mission_goals( arg3 );
      if ( type < 0 )
       type = atoi( arg3 );
      if ( type < 0 || type > MAX_GTYPES )
       {
        ch_printf( ch, "Not a valid Mission Goal\r\n");
        return;
       }

     if ( argument[0] == '\0' )
       {
        ch_printf( ch, "Usage: setmission <id> goal2 <type> <value>\r\n");
        return;
       }

     gvalue = atoi( argument );

     if ( type == GOAL_TIME )
      if ( !mission->timer || mission->timer < gvalue )
        {
         ch_printf( ch, "Mission timer must be more then time goal\r\n");
         return;
        }
      
     if ( type == GOAL_HP )
      if ( gvalue < 1 || gvalue > 99 )
        {
         ch_printf( ch, "HP Goal range is 1 - 99 percent.\r\n");
         return;
        }
      
     if ( type == GOAL_MOB )
      if ( gvalue < 1 || gvalue > ( MMOB - 2 )  )
        {
         ch_printf( ch, "Which mob should they kill first? 1 - %d.\r\n", ( MMOB - 2 ) );
         return;
        }
      
      mission->goal_type[2] = type;
      mission->goal[2] = gvalue;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   if( !strcmp( arg2, "goal3" ) )
   {
     if ( arg3[0] == '\0' )
       {
        ch_printf( ch, "Usage: setmission <id> goal3 <type> <value>\r\n");
        return;
       }

      type = get_mission_goals( arg3 );
      if ( type < 0 )
       type = atoi( arg3 );
      if ( type < 0 || type > MAX_GTYPES )
       {
        ch_printf( ch, "Not a valid Mission Goal\r\n");
        return;
       }

     if ( argument[0] == '\0' )
       {
        ch_printf( ch, "Usage: setmission <id> goal3 <type> <value>\r\n");
        return;
       }

     gvalue = atoi( argument );

     if ( type == GOAL_TIME )
      if ( !mission->timer || mission->timer < gvalue )
        {
         ch_printf( ch, "Mission timer must be more then time goal\r\n");
         return;
        }
      
     if ( type == GOAL_HP )
      if ( gvalue < 1 || gvalue > 99 )
        {
         ch_printf( ch, "HP Goal range is 1 - 99 percent.\r\n");
         return;
        }
      
     if ( type == GOAL_MOB )
      if ( gvalue < 1 || gvalue > ( MMOB - 2 ) )
        {
         ch_printf( ch, "Which mob should they kill first? 1 - %d.\r\n", ( MMOB - 2 ) );
         return;
        }
      
      mission->goal_type[3] = type;
      mission->goal[3] = gvalue;
      send_to_char( "Done.\r\n", ch );
      save_mission( mission );
      return;
   }

   do_setmission( ch, "" );
   return;
}

/*
 * Show mission info
 */
void do_showmission( CHAR_DATA * ch, char *argument )
{
   int mid, x;
   MISSION_DATA *mission;
   char arg1[MAX_INPUT_LENGTH];
   char arg2[MAX_INPUT_LENGTH];

   if( IS_NPC( ch ) )
   {
      send_to_char( "Huh?\r\n", ch );
      return;
   }

   argument = one_argument( argument, arg1 );
   argument = one_argument( argument, arg2 );

   if( arg1[0] == '\0' && arg2[0] == '\0' )
   {
      send_to_char( "Usage: showmission <mission id>\r\n", ch );
      return;
   }

   mid = atoi( arg1 );
   mission = get_mission_id( mid );
   if( !mission || ( !mission->ready && !IS_IMMORTAL( ch ) ) )
   {
      send_to_char( "No such mission.\r\n", ch );
      return;
   }
   
   if( arg2[0] == '\0' )
    {
      ch_printf( ch, "&c(&W%-3d&c)          &R%-15s\r\n", mission->id, mission->name );
      ch_printf( ch, "&C--------------------------------------------------------------\r\n");
      ch_printf( ch, "&CMission Info&c:                          &CEnemies&c:\r\n" );
      ch_printf( ch, "&cReward:&W    %-3dMP                        &R%s&W\r\n", mission->reward, mission->short_descr[0] );
     if ( mission->mob_name[1] ) 
      ch_printf( ch, "&cTimer:&W     %-1.1f min                      %s \r\n", ( ( (double)mission->timer * 10 ) / 60 ), mission->short_descr[1] );
     if ( !mission->mob_name[1] ) 
      ch_printf( ch, "&cTimer:&W     %-1.1f min                  \r\n", ( ( (double)mission->timer * 10 ) / 60 ) );
     if ( mission->mob_name[2] ) 
      ch_printf( ch, "&W                                        %s\r\n", mission->short_descr[2]);
     if ( mission->mob_name[3] ) 
      ch_printf( ch, "&W                                        %s\r\n", mission->short_descr[3]);
     if ( mission->mob_name[4] ) 
      ch_printf( ch, "&W                                        %s\r\n", mission->short_descr[4]);
     if ( mission->mob_name[5] ) 
      ch_printf( ch, "&W                                        %s\r\n", mission->short_descr[5]);
     if ( mission->mob_name[6] ) 
      ch_printf( ch, "&W                                        %s\r\n", mission->short_descr[6]);
     if ( mission->mob_name[7] ) 
      ch_printf( ch, "&W                                        %s\r\n", mission->short_descr[7]);
     if ( mission->mob_name[8] ) 
      ch_printf( ch, "&W                                        %s\r\n", mission->short_descr[8]);
      ch_printf( ch, "&c\r\n");

      ch_printf( ch, "&CBonus Objectives&c:\r\n" );
     for ( x = 0; x < MAX_GOALS; x++ )
      {
      if ( mission->goal_type[x] )
       {
       if ( mission->goal_type[x] == GOAL_TIME )
        ch_printf( ch, "&r   *&W Beat mission in under %-1.1f min\r\n", ( ( (double)mission->goal[x] * 10 ) / 60 ) );
       if ( mission->goal_type[x] == GOAL_HP )
        ch_printf( ch, "&r   *&W Beat mission with more then %d percent HP\r\n", mission->goal[x] );
       if ( mission->goal_type[x] == GOAL_MOB )
        ch_printf( ch, "&r   *&W Defeat %s before anyone else\r\n", mission->short_descr[mission->goal[x]] );
       }
      }

     if ( IS_IMMORTAL( ch ) )
      {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&CImmortal Info&c:\r\n" );
       ch_printf( ch, "&cFilename&W:  %s\r\n", mission->filename );
       ch_printf( ch, "&cStatus&W:    %s\r\n", mission->ready ? "&GReady" : "&RLocked" );

       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&R Target NPC:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[0] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[0] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[0] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[0] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[0], mission->max_hit[0], get_race_num( mission->race[0] ) );

       if ( mission->mob_name[1] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 1:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[1] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[1] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[1] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[1] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[1], mission->max_hit[1], get_race_num( mission->race[1] ) ); 
        }

       if ( mission->mob_name[2] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 2:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[2] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[2] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[2] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[2] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[2], mission->max_hit[2], get_race_num( mission->race[2] ) ); 
        }

       if ( mission->mob_name[3] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 3:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[3] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[3] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[3] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[3] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[3], mission->max_hit[3], get_race_num( mission->race[3] ) ); 
        }

       if ( mission->mob_name[4] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 4:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[4] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[4] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[4] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[4] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[4], mission->max_hit[4], get_race_num( mission->race[4] ) ); 
        }

       if ( mission->mob_name[5] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 5:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[5] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[5] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[5] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[5] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[5], mission->max_hit[5], get_race_num( mission->race[5] ) ); 
        }

       if ( mission->mob_name[6] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 6:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[6] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[6] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[6] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[6] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[6], mission->max_hit[6], get_race_num( mission->race[6] ) ); 
        }

       if ( mission->mob_name[7] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 7:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[7] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[7] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[7] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[7] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[7], mission->max_hit[7], get_race_num( mission->race[7] ) ); 
        }

       if ( mission->mob_name[8] != NULL )
        {
       ch_printf( ch, "&c\r\n");
       ch_printf( ch, "&C Underling 8:\r\n");
       ch_printf( ch, "&c  Name&W:  %s\r\n", mission->mob_name[8] );
       ch_printf( ch, "&c  SDesc&W: %s\r\n", mission->short_descr[8] );
       ch_printf( ch, "&c  LDesc&W: %s\r\n", mission->long_descr[8] );
       ch_printf( ch, "&c  PL&W: %s\r\n", num_punct_ld( mission->power[8] ) );
       ch_printf( ch, "&c  Lv&W: %-3d  &cHP:&W %-5d  &cRace:&W  %-10s\r\n",
        mission->level[8], mission->max_hit[8], get_race_num( mission->race[8] ) ); 
        }

      }
      ch_printf( ch, "&C--------------------------------------------------------------\r\n");
      ch_printf( ch, "&c Use '&Cmission %d start&c' to begin&w\r\n", mission->id );
      return;
    }

 send_to_char( "Usage: showmission <mission id>\r\n", ch );
 return;
}

void do_makemission( CHAR_DATA * ch, char *argument )
{
   MISSION_DATA *mission;
   int mid = 0;

   if( !argument || argument[0] == '\0' )
   {
      send_to_char( "Usage: makemission <mission name>\r\n", ch );
      return;
   }

   mid = mission_id( mid );
   if ( mid >= MAX_MISSION )
   {
      send_to_char( "Maximum missions reached.\r\n", ch );
      send_to_char(" Consider changing MAX_MISSION in mud.h\r\n", ch );
      return;
   }


/*  Otherwise it would be possible to create multiple missions
    with the same name. Bad thing... */

   set_char_color( AT_PLAIN, ch );
   mission = get_mission( argument );
   if( mission )
   {
      send_to_char( "There is already a mission with that name.\r\n", ch );
      return;
   }

   CREATE( mission, MISSION_DATA, 1 );
   LINK( mission, first_mission, last_mission, next, prev );
   mission->name = STRALLOC( argument );
   mission->id = mid;
   mission->timer = 18;
   mission->ready = FALSE;
   send_to_char( "&WMission Created...&w\r\n", ch );
}

/* Simple counter for new mission ID */
int mission_id( int mid )
{
   MISSION_DATA *mission;
   int count = 1;
   
   for( mission = first_mission; mission; mission = mission->next )
      count++;
  
   return count;
}

void do_missions( CHAR_DATA * ch, char *argument )
{
   MISSION_DATA *mission;
   char arg1[MAX_INPUT_LENGTH];
   char arg2[MAX_INPUT_LENGTH];
   char arg3[MAX_INPUT_LENGTH];
   char buf[MAX_INPUT_LENGTH];
   int count = 1, mid;

   if( IS_NPC( ch ) )
    {
      send_to_char( "Huh?\r\n", ch );
      return;
    }

   if( ch->fighting )
    {
      send_to_char( "You are a little busy right now.\r\n", ch );
      return;
    }

   argument = one_argument( argument, arg1 );
   argument = one_argument( argument, arg2 );
   argument = one_argument( argument, arg3 );

   if( arg1[0] == '\0' && arg2[0] == '\0')
    {
   
    set_char_color( AT_YELLOW, ch );
    send_to_char( "Celestial Knights Missions:\r\n", ch );
    ch_printf( ch, "&c(&WID &c) &WName                     &c(&RPowerlevel&c)          &c(&WRank&c)\r\n");
    ch_printf( ch, "&C-------------------------------------------------------------------\r\n");

    for( mission = first_mission; mission; mission = mission->next )
    {
      if ( !mission->ready && !IS_IMMORTAL( ch ) )
	continue;

      if ( !IS_IMMORTAL( ch ) )
       ch_printf( ch, "&c(&W%-3d&c) &W%-25s&c(&R%-20s&c) ",
                  mission->id, mission->name, num_punct_ld( mission->power[0] ) );

      if ( IS_IMMORTAL( ch ) )
       ch_printf( ch, "&c(&W%-3d&c)&c[%s&c] &W%-25s&c(&R%-20s&c) ",
                  mission->id, mission->ready ? "&GX" : "&RX", mission->name, num_punct_ld( mission->power[0] ) );

      if ( ch->pcdata->mrank[count] > 0 )
       ch_printf(ch, "&Y(&R*&Y) ");
      if ( ch->pcdata->mrank[count] > 1 )
       ch_printf(ch, "&Y(&R*&Y) ");
      if ( ch->pcdata->mrank[count] > 2 )
       ch_printf(ch, "&Y(&R*&Y) ");
      if ( ch->pcdata->mrank[count] > 3 )
       ch_printf(ch, "&Y(&R*&Y) ");
      if ( ch->pcdata->mrank[count] > 4 )
       ch_printf(ch, "&Y(&R*&Y) ");

       send_to_char( "&w\r\n", ch );
       count++;
    }

    if( !count )
    {
       set_char_color( AT_BLOOD, ch );
       send_to_char( "There are no missions currently available.\r\n", ch );
    }
   
    send_to_char( "\r\n", ch );
    send_to_char( "&cUse '&Cmission <ID#>&c' to see more information.\r\n", ch );
    send_to_char( "&cUse '&Cmission <ID#> start&c' to begin mission.\r\n", ch );
    send_to_char( "&cUse '&Cmission buy&c' to see MP exchange.\r\n", ch );

    send_to_char( "\r\n", ch );
    return;
   }

/**************************************************************************/
   if ( !str_cmp( arg1, "abort" ) )
    {
     if ( ch->pcdata->cmission == 0 )
      {
        send_to_char( "&RYou are not on a mission!&w\r\n", ch );
        return;
      }
     fail_mission( ch );
     return;
    }

   if ( !str_cmp( arg1, "buy" ) )
    {
    int mpcost[25], objcost = 0;
    OBJ_DATA * obj;

/* MP costs for mission items */
/******************************/

    mpcost[1] = 10;
    mpcost[2] = 5000;
    mpcost[3] = 25000;
    mpcost[4] = 25000;
    mpcost[5] = 25000;

/******************************/

    if( arg2[0] == '\0')
     {
      set_char_color( AT_YELLOW, ch );
      send_to_char( "Celestial Knights MP Exchange:\r\n", ch );
      ch_printf( ch, "&c(&WID &c)  &WItem                Cost\r\n");
      ch_printf( ch, "&C--------------------------------------------------------------\r\n");
      ch_printf(ch, "\r\n");
      ch_printf( ch, "&c(&W  1&c)&W Senzu Bean            %-6d&cMP&W    \r\n", mpcost[1]); 
      ch_printf( ch, "&c(&W  2&c)&W &r[&W Tapion Blade&r ]&W      %-6d&cMP&W    \r\n", mpcost[2]); 
      ch_printf( ch, "&c(&W  3&c)&W Permanant No Hunger   %-6d&cMP&W    \r\n", mpcost[3]); 
      ch_printf( ch, "&c(&W  4&c)&W Permanant No Thirst   %-6d&cMP&W    \r\n", mpcost[4]); 
      ch_printf( ch, "&c(&W  5&c)&W Permanant No Sleep    %-6d&cMP&W    \r\n", mpcost[5]); 
      ch_printf(ch, "\r\n");
      ch_printf( ch, "&C--------------------------------------------------------------\r\n");
      ch_printf(ch, "&cUse '&Cmission buy <ID>&c' to purchase item.&w\r\n");
      ch_printf(ch, "&cUse '&Cmission buy info <ID>&c' to see more info.&w\r\n");
      ch_printf(ch, "&YYou have %d MP&w\r\n", ch->pcdata->mpoints);
      ch_printf(ch, "\r\n");
      return;
     }

/*
 * Displays information on selected item.
 */

   if ( !str_cmp( arg2, "info" ) )
    {
    if( arg3[0] == '\0')
     {
       ch_printf(ch, "&cThat is not a valid item.&w\r\n");
       ch_printf(ch, "&cuse 'mission buy info <ID#>'&w\r\n");
       ch_printf(ch, "\r\n");
       return;
     }

    switch( atoi( arg3 ) )
     {
      default:
       ch_printf(ch, "&cThat is not a valid item.&w\r\n");
       ch_printf(ch, "&cuse 'mission buy info <ID#>'&w\r\n");
       ch_printf(ch, "\r\n");
       break;

      case 1:
       obj = create_object( get_obj_index( OBJ_VNUM_SENZU ), 0 );
       ch_printf( ch, "&W                     %-15s\r\n", obj->short_descr );
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf( ch, "&cItem Type&C:&W   Senzu Beam   \r\n" );
       ch_printf( ch, "&cMP Cost&C:&W     %d   \r\n", mpcost[ atoi( arg3 ) ]);
       ch_printf( ch, "&c A mysterious bean that fully restores HP/KI/MV.\r\n");
       ch_printf( ch, "&c Also fills hunger/thirst/sleep.\r\n");
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf(ch, "\r\n");
       extract_obj( obj );
       break;
   
      case 2:
       obj = create_object( get_obj_index( OBJ_VNUM_TAPION ), 0 );
       ch_printf( ch, "&W                     %-15s\r\n", obj->short_descr );
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf( ch, "&cItem Type&C:&W   Sword   \r\n" );
       ch_printf( ch, "&cMin. damage&C:&W %d   \r\n", obj->value[1] );
       ch_printf( ch, "&cMax. damage&C:&W %d   \r\n", obj->value[2] );
       ch_printf( ch, "&cFlags&C:&W       %s   \r\n", flag_string( obj->extra_flags, o_flags ) );
       ch_printf( ch, "&cMP Cost&C:&W     %d   \r\n", mpcost[ atoi( arg3 ) ]);
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf(ch, "\r\n");
       extract_obj( obj );
       break;

      case 3:
       sprintf( buf, "&GNo Hunger&W");
       ch_printf( ch, "&W                     %-15s\r\n", buf );
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf( ch, "&cItem Type&C:&W   Player Bonus   \r\n" );
       ch_printf( ch, "&cMP Cost&C:&W     %d   \r\n", mpcost[ atoi( arg3 ) ]);
       ch_printf( ch, "&c Removes the need to eat food for regen bonus.\r\n");
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf(ch, "\r\n");
       break;

      case 4:
       sprintf( buf, "&BNo Thirst&W");
       ch_printf( ch, "&W                     %-15s\r\n", buf );
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf( ch, "&cItem Type&C:&W   Player Bonus   \r\n" );
       ch_printf( ch, "&cMP Cost&C:&W     %d   \r\n", mpcost[ atoi( arg3 ) ]);
       ch_printf( ch, "&c Removes the need to drink for regen bonus.\r\n");
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf(ch, "\r\n");
       break;

      case 5:
       sprintf( buf, "&PNo Sleep&W");
       ch_printf( ch, "&W                     %-15s\r\n", buf );
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf( ch, "&cItem Type&C:&W   Player Bonus   \r\n" );
       ch_printf( ch, "&cMP Cost&C:&W     %d   \r\n", mpcost[ atoi( arg3 ) ]);
       ch_printf( ch, "&c Removes the need to sleep and sleep deprevation.\r\n");
       ch_printf( ch, "&C--------------------------------------------------------------\r\n");
       ch_printf(ch, "\r\n");
       break;

     }
     return;
    }

    switch( atoi( arg2 ) )
     {
      default:
       ch_printf(ch, "&cThat is not a valid item.&w\r\n");
       break;

      case 1:
       objcost = mpcost[ atoi( arg2 ) ];
       if ( ch->pcdata->mpoints < objcost )
        {
         ch_printf(ch, "&cYou do not have enough mission points.&w\r\n");
         return;
        }
         ch_printf(ch, "&cYou exchange %dMP for a senzu bean.&w\r\n", objcost );
         ch->pcdata->mpoints -= objcost;

         obj = create_object( get_obj_index( OBJ_VNUM_SENZU ), 0 );
         obj_to_char( obj, ch );
       break;

      case 2:
       objcost = mpcost[ atoi( arg2 ) ];
       if ( ch->pcdata->mpoints < objcost )
        {
         ch_printf(ch, "&cYou do not have enough mission points.&w\r\n");
         return;
        }
         ch_printf(ch, "&cYou exchange %dMP for a &r[&W Tapion Blade &r]&W.&w\r\n", objcost );
         ch->pcdata->mpoints -= objcost;

         obj = create_object( get_obj_index( OBJ_VNUM_TAPION ), 0 );
         obj_to_char( obj, ch );
       break;

      case 3:
       objcost = mpcost[ atoi( arg2 ) ];
       if ( ch->pcdata->mpoints < objcost )
        {
         ch_printf(ch, "&cYou do not have enough mission points.&w\r\n");
         return;
        }

       if ( IS_ANDROID( ch ) || IS_NAMEK( ch ) || NO_HUNGER( ch ) )
        {
         ch_printf(ch, "&cYou already do not ever get hungry.&w\r\n");
         return;
        }

         ch_printf(ch, "&cYou exchange %dMP to never get hungry again.&w\r\n", objcost );
         ch->pcdata->mpoints -= objcost;
         ch->pcdata->condition[COND_FULL] = 200;
         SET_BIT( ch->pcdata->flags, PCFLAG_NOHUNGER );
       break;

      case 4:
       objcost = mpcost[ atoi( arg2 ) ];
       if ( ch->pcdata->mpoints < objcost )
        {
         ch_printf(ch, "&cYou do not have enough mission points.&w\r\n");
         return;
        }

       if ( IS_ANDROID( ch ) || NO_THIRST( ch ) )
        {
         ch_printf(ch, "&cYou already do not ever get thirsty.&w\r\n");
         return;
        }

         ch_printf(ch, "&cYou exchange %dMP to never get thirsty again.&w\r\n", objcost );
         ch->pcdata->mpoints -= objcost;
         ch->pcdata->condition[COND_THIRST] = 200;
         SET_BIT( ch->pcdata->flags, PCFLAG_NOTHIRST );
       break;

      case 5:
       objcost = mpcost[ atoi( arg2 ) ];
       if ( ch->pcdata->mpoints < objcost )
        {
         ch_printf(ch, "&cYou do not have enough mission points.&w\r\n");
         return;
        }

       if ( IS_ANDROID( ch ) || NO_SLEEP( ch ) )
        {
         ch_printf(ch, "&cYou already do not ever get tired.&w\r\n");
         return;
        }

         ch_printf(ch, "&cYou exchange %dMP to never get tired again.&w\r\n", objcost );
         ch->pcdata->mpoints -= objcost;
         ch->mental_state = 0;
         SET_BIT( ch->pcdata->flags, PCFLAG_NOSLEEP );
       break;

     }

     return;
    }

   mid = atoi( arg1 );
   mission = get_mission_id( mid );

   if( !mission || ( !mission->ready && !IS_IMMORTAL( ch ) ) )
   {
      send_to_char( "No such mission.\r\n", ch );
      return;
   }

/**************************************************************************/
   if( mission && arg2[0] == '\0')
      do_showmission( ch, arg1 );

   if ( !str_cmp( arg2, "start" ) )
    {
     CHAR_DATA * victim;
     MOB_INDEX_DATA * mob;
      
     if ( ch->pcdata->cmission > 0 )
      {
        send_to_char( "&RYou are already on a mission!&w\r\n", ch );
        send_to_char( "&cuse 'mission abort' to end the current mission.&w\r\n", ch );
        return;
      }

     if ( !check_mission_1( ch ) && !check_mission_2( ch ) )
      {
        send_to_char( "&RNo mission zones are currently availible right now.&w\r\n", ch );
        return;
      }
      
     int rnum[2], pnum[2], rnum_lo[2], rnum_hi[2], rcount = 0;

     if ( check_mission_1( ch ) )
      {
       rcount++;
       rnum[rcount] = number_range( ROOM_M1_LO, ROOM_M1_HI );
       rnum_lo[rcount] = ROOM_M1_LO;
       rnum_hi[rcount] = ROOM_M1_HI;
       pnum[rcount] = number_range( ROOM_M1_LO, ROOM_M1_HI );
       clean_mission_1( );       
      }
     if ( check_mission_2( ch ) )
      {
       rcount++;
       rnum[rcount] = number_range( ROOM_M2_LO, ROOM_M2_HI );
       rnum_lo[rcount] = ROOM_M2_LO;
       rnum_hi[rcount] = ROOM_M2_HI;
       pnum[rcount] = number_range( ROOM_M2_LO, ROOM_M2_HI );
       clean_mission_2( );       
      }
     
     int pickroom = number_range( 1, rcount );

      
     if( ( mob = get_mob_index( MOB_VNUM_MISSION) ) == NULL )
        return;

     if ( !mission->mob_name[0] )
      {
        send_to_char( "&RThis mission is broken, please report it.&w\r\n", ch );
        return;
      }
      
     /* No underlings? Then drop target */
       if ( !mission->mob_name[1] )
        {       
          victim = create_mobile( mob );
          restat_target( mission, victim );
          char_to_room( victim, get_room_index( rnum[pickroom] ) );
        }
       else if ( mission->mob_name[1] || mission->mob_name[1] != NULL )
        {
         int mcount = 0;
         for ( mcount = 1; mcount < MMOB; mcount++ )
          {
           if ( !mission->mob_name[mcount] )
            break;

           rnum[pickroom] = number_range( rnum_lo[pickroom], rnum_hi[pickroom] );

           victim = create_mobile( mob );
           restat_mission( mission, victim, mcount );
           char_to_room( victim, get_room_index( rnum[pickroom] ) );
          }
        }

        ch->retran = ch->in_room->vnum;
        char_from_room( ch );
        ch_printf( ch, "&YYou start your mission to defeat %s.&w\r\n", mission->mob_name[0]);
        act( AT_IMMORT, "$n flies off into the distance until you can't see them anymore.", ch, NULL, NULL, TO_ROOM );
        char_to_room( ch, get_room_index( pnum[pickroom] ) );

        ch->pcdata->cmission = mission->id;
        ch->pcdata->mattempts++;

       if ( !mission->timer )
        ch->pcdata->cm_timer = 18;
       else if ( mission->timer )
        ch->pcdata->cm_timer = mission->timer;

        do_look( ch, "auto" );
        return;
    }

 return;
}
