/*
 *                               Celestial Knights
 *                             Benjamin 'Tzu' Peters
 *                                   majin.c
 *                    Module for majin racial forms and skills
 */

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "mud.h"
#include "sha256.h"

void gain_absorb( CHAR_DATA * ch, long gain )
{
 long plgain = number_range( ( long )( gain * .75 ), ( int )( gain * 1.25 ) );

   if( IS_NPC( ch ) )
      return;

   if ( !IS_MAJIN( ch ) )
      return;
   
   if ( gain == 0 )
    plgain = 1;

   if ( plgain > ( ch->base_pl *.30 ) )
    plgain = number_range( ( long )( (ch->base_pl*.20) + 1 ), ( long )( (ch->base_pl*.30) + 1 ) );

/* Immortal set bonus */ 
   plgain *= PL_BONUS;


   ch->absorb_pl = UMAX( 1, ch->absorb_pl + plgain );

   if ( !ch->fighting )
    {
     set_char_color( AT_PINK, ch );
     ch_printf( ch, "You gain %s powerlevel from absorption!\n", num_punct_ld(plgain) );
     set_char_color( AT_WHITE, ch );
    }	
   return;
}

void majin_absorb( CHAR_DATA *ch, CHAR_DATA *victim )
{
   short percent;

   if ( !IS_MAJIN( ch ) )
     return;

   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_majin_absorb] <= 0 )
     return;
     
   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_majin_absorb];

   if( number_percent( ) > percent )
   {

     act( AT_MAGIC, "You launch a piece of your body at $N but miss completely.\r\n", ch, NULL, victim, TO_CHAR );
     act( AT_MAGIC, "$n launches a piece of their body at $N but miss completely.\r\n", ch, NULL, victim, TO_ROOM );
      learn_from_failure( ch, gsn_majin_absorb );
      return;
   }

   act( AT_MAGIC, "You launch a piece of your body at $N and absorb their power.\r", ch, NULL, victim, TO_CHAR );
   act( AT_MAGIC, "$n launches a piece of their body at $N and absorbs them.\r\n", ch, NULL, victim, TO_ROOM );
  
   gain_absorb(ch, sqrt( ( GET_POWER(victim) * 10 ) ) );
   learn_from_success( ch, gsn_majin_absorb );
 return;
}
