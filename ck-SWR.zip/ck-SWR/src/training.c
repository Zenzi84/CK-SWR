/*
 * training.c
 * Benjamin 'Tzu' Peters
 * module for commands used for training stats
 */

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "mud.h"
#include "sha256.h"


/* Local variables and defines */
long cost = 0;

/* local functions */
long cost_calc( CHAR_DATA *ch, long move );


/* Modifiers for movement cost */
long cost_calc( CHAR_DATA *ch, long move )
{

  move = 100;
  move *= ( (double)(GRAVITY(ch) ) / 100 ) + 1;

  /* Gear Weight */
    move *= ( (double)(WEIGHTED( ch )) / 100 ) + 1;
    
 return move;
}

void trans_chance( CHAR_DATA * ch )
{
   int sn = 0, sn2 = 0, sn3 = 0, sn4 = 0;

   sn  = gsn_transform1;
   sn2 = gsn_transform2;
   sn3 = gsn_transform3;
   sn4 = gsn_transform4;

   if ( !IS_ICER( ch ) )
      return;
   
   if ( IS_ICER( ch ) )
    {
      if ( number_percent( ) <= number_range( 1, 100 ))
       if ( ch->pcdata->learned[sn] <= 0 )
        {
          ch->pcdata->learned[sn] = 20;
          do_transform( ch, "first" );
        }

      if ( number_percent( ) <= number_range( 1, 50 ) )
       if ( ch->pcdata->learned[sn] == 100 )
        if ( ch->pcdata->learned[sn2] <= 0 )
         if ( GET_TRANS( ch ) == 2 )
         {
           ch->pcdata->learned[sn2] = 20;
           do_transform( ch, "second" );
         }
      
      if ( number_percent( ) <= number_range( 1, 25 ) )
       if ( ch->pcdata->learned[sn2] == 100 )
        if ( ch->pcdata->learned[sn3] <= 0 )
         if ( GET_TRANS( ch ) == 3 )
         {
           ch->pcdata->learned[sn3] = 20;
           do_transform( ch, "third" );
         }
      
      if ( number_percent( ) <= number_range( 1, 25 ) )
       if ( ch->pcdata->learned[sn3] == 100 )
        if ( ch->pcdata->learned[sn4] <= 0 )
         if ( GET_TRANS( ch ) == 4 )
         {
           ch->pcdata->learned[sn3] = 20;
           do_transform( ch, "fourth" );
         }
   }
    return;
}

/* Skill to restore ki */
void do_trance( CHAR_DATA *ch, char *argument ) 
{
 char arg[MAX_INPUT_LENGTH];
 int percent;

 strcpy( arg, "trance");

   if( IS_NPC( ch ) )
      return;

   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_trance] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
  }
  
   if ( ch->mana >= ch->max_mana)
    { 
     ch->mana = ch->max_mana;
     send_to_char( "Your ki is already at its maximum.\r\n", ch );
     return;
    }

   switch ( ch->substate )
   {
      default:

         if( !IS_AWAKE( ch ) )
         {
            send_to_char( "In your dreams, or what?\r\n", ch );
            return;
         }

         send_to_char( "&GYou sit down, cross your legs and enter into a trance.\r\n", ch );
         ch->position = POS_SITTING;
      
         add_timer( ch, TIMER_DO_FUN, 2, do_trance, 1 );
         ch->dest_buf = str_dup( arg );
         return;

      case 1:
         if( !ch->dest_buf )
            return;

         strcpy(arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou stop meditating and stand up.\r\n", ch );
         ch->position = POS_STANDING;
         return;
   }

   ch->substate = SUB_NONE;
   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_trance];

   if( number_percent( ) > percent )
   {
      set_char_color( AT_WHITE, ch );
      send_to_char( "You try to enter deeper into a trance, but lose your concentration.\r\n", ch );
      learn_from_failure( ch, gsn_trance );
      ch->position = POS_STANDING;
      return;
   }

      send_to_char( "&GYou feel your ki flourish from intense meditation.\r\n", ch );
      learn_from_success( ch, gsn_trance );
      ch->mana += ( ch->max_mana/10 );
      ch->position = POS_STANDING;
        
      if ( ch->mana >= ch->max_mana )
         ch->mana = ch->max_mana;

      return;
}

void do_pushups( CHAR_DATA *ch, char *argument ) 
{
 char arg[MAX_INPUT_LENGTH];
 bool successful = FALSE;

  strcpy( arg, "pushup");

   if( IS_NPC( ch ) )
      return;

   cost = cost_calc( ch, cost );

   if ( IS_ANDROID( ch ) )
    {        
     send_to_char( "Training your mechanical body would be pointless.\r\n", ch );
     return;
    }

   if ( ch->move < cost )
    {        
     send_to_char( "You feel much to tired to do any exercises.\r\n", ch );
     return;
    }

   if ( IS_ISOLATION( ch ) )
    {        
     send_to_char( "It is hard to exercise in an isolation chamber.\r\n", ch );
     return;
    }

   if ( IS_ISOLATION( ch ) )
    {        
     send_to_char( "It is hard to exercise in an isolation chamber.\r\n", ch );
     return;
    }

   switch ( ch->substate )
   {
      default:

         if( !IS_AWAKE( ch ) )
         {
            send_to_char( "In your dreams, or what?\r\n", ch );
            return;
         }

         send_to_char( "&GYou begin a rigorious regiment of pushups.\r\n", ch );
         ch->move -= cost;
         add_timer( ch, TIMER_DO_FUN, 2, do_pushups, 1 );
         ch->dest_buf = str_dup( arg );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy(arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou fail to complete your training.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;
   int stat_chance = number_range( 1, 10 );

   if( stat_chance >= 3 )
      successful = TRUE;

      if( !successful )
      {
         send_to_char( "&RYou feel that you have wasted alot of energy for next to nothing...\r\n", ch );
         gain_power( ch, GET_PLGAIN(ch)/100 + 1, FALSE );
         return;
      }

      send_to_char( "&GAfter much of excercise you feel a little stronger.\r\n", ch );
      gain_power( ch, GET_PLGAIN(ch) / 4, FALSE );
      trans_chance( ch );
   
 /*
  *    Chance for stats to increase
  */
    if ( stat_chance >= 7 && stat_chance <= 9)
     hp_increase( ch, FALSE );

    if ( stat_chance == 10 &&
         ch->perm_str < ( 20 + race_table[ch->race].str_plus ) )
     {
      send_to_char( "&YYour strength has increased!\r\n", ch );
      ch->perm_str++;
     }
      return;
}

void do_aura( CHAR_DATA *ch, char *argument ) 
{
 char arg[MAX_INPUT_LENGTH];
 bool successful = FALSE;

  strcpy( arg, "aura");

   if( IS_NPC( ch ) )
      return;

   cost = cost_calc( ch, cost );

   if ( IS_ANDROID( ch ) )
    {        
     send_to_char( "Training your mechanical body would be pointless.\r\n", ch );
     return;
    }

   if ( ch->move < cost )
    {        
     send_to_char( "You feel much to tired to do any exercises.\r\n", ch );
     return;
    }

   if ( IS_ISOLATION( ch ) )
    {        
     send_to_char( "It is hard to exercise in an isolation chamber.\r\n", ch );
     return;
    }

   if ( IS_ISOLATION( ch ) )
    {        
     send_to_char( "It is hard to exercise in an isolation chamber.\r\n", ch );
     return;
    }

   switch ( ch->substate )
   {
      default:

         if( !IS_AWAKE( ch ) )
         {
            send_to_char( "In your dreams, or what?\r\n", ch );
            return;
         }

         send_to_char( "&GYou begin to focus on your aura.\r\n", ch );
         ch->move -= cost;
         add_timer( ch, TIMER_DO_FUN, 2, do_aura, 1 );
         ch->dest_buf = str_dup( arg );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy(arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou fail to complete your training.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;
   int stat_chance = number_range( 1, 10 );

   if( stat_chance >= 3 )
      successful = TRUE;

      if( !successful )
      {
         send_to_char( "&RYou feel that you have wasted alot of energy for next to nothing...\r\n", ch );
         gain_power( ch, GET_PLGAIN(ch)/100 + 1, FALSE );;
         return;
      }

      send_to_char( "&GAfter much of excercise you feel a little stronger.\r\n", ch );
      gain_power( ch, GET_PLGAIN(ch) / 4, FALSE );;
      trans_chance( ch );
     
 /*
  *    Chance for stats to increase
  */
    if ( stat_chance >= 7 && stat_chance <= 9)
     ki_increase( ch, FALSE );

    if ( stat_chance == 10 &&
         ch->perm_frc < ( 20 + race_table[ch->race].frc_plus ) )
     {
      send_to_char( "&YYour energy has increased!\r\n", ch );
      ch->perm_frc++;
     }
      return;
}

void do_situp( CHAR_DATA *ch, char *argument )
{
 char arg[MAX_INPUT_LENGTH];
 bool successful = FALSE;

  strcpy( arg, "situp");

   if( IS_NPC( ch ) )
      return;

   cost = cost_calc( ch, cost );

   if ( IS_ANDROID( ch ) )
    {        
     send_to_char( "Training your mechanical body would be pointless.\r\n", ch );
     return;
    }

   if ( ch->move < cost )
    {        
     send_to_char( "You feel much to tired to do any exercises.\r\n", ch );
     return;
    }

   if ( IS_ISOLATION( ch ) )
    {        
     send_to_char( "It is hard to exercise in an isolation chamber.\r\n", ch );
     return;
    }


   switch ( ch->substate )
   {
      default:

         if( !IS_AWAKE( ch ) )
         {
            send_to_char( "In your dreams, or what?\r\n", ch );
            return;
         }

         send_to_char( "&GYou begin a rigorious regiment of situps.\r\n", ch );
         ch->move -= cost;
         add_timer( ch, TIMER_DO_FUN, 2, do_situp, 1 );
         ch->dest_buf = str_dup( arg );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy(arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou fail to complete your training.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;
   int stat_chance = number_range( 1, 10 );

   if( stat_chance >= 3 )
      successful = TRUE;

      if( !successful )
      {
         send_to_char( "&RYou feel that you have wasted alot of energy for next to nothing...\r\n", ch );
         gain_power( ch, GET_PLGAIN(ch)/100 + 1, FALSE );;
         return;
      }

      send_to_char( "&GAfter much of excercise you feel a little stronger.\r\n", ch );
      gain_power( ch, GET_PLGAIN(ch) / 4, FALSE );;
      trans_chance( ch );
     
 /*
  *    Chance for stats to increase
  */
    if ( stat_chance >= 7 && stat_chance <= 9)
     hp_increase( ch, FALSE );

    if ( stat_chance == 10 &&
         ch->perm_con < ( 20 + race_table[ch->race].con_plus ) )
     {
      send_to_char( "&YYour constitution has increased!\r\n", ch );
      ch->perm_con++;
     }
 return;
}

void do_study( CHAR_DATA *ch, char *argument )
{
 char arg[MAX_INPUT_LENGTH];
 bool successful = FALSE;

  strcpy( arg, "study");

   if( IS_NPC( ch ) )
      return;

   cost = cost_calc( ch, cost );

   if ( IS_ANDROID( ch ) )
    {        
     send_to_char( "Training your mechanical body would be pointless.\r\n", ch );
     return;
    }

   if ( ch->move < cost )
    {        
     send_to_char( "You feel much to tired to do any exercises.\r\n", ch );
     return;
    }

   if ( IS_ISOLATION( ch ) )
    {        
     send_to_char( "It is hard to exercise in an isolation chamber.\r\n", ch );
     return;
    }

   switch ( ch->substate )
   {
      default:

         if( !IS_AWAKE( ch ) )
         {
            send_to_char( "In your dreams, or what?\r\n", ch );
            return;
         }

         send_to_char( "&GYou pull out several books and begin a study session.\r\n", ch );
         ch->move -= cost;
         add_timer( ch, TIMER_DO_FUN, 2, do_study, 1 );
         ch->dest_buf = str_dup( arg );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy(arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou fail to complete your training.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;
   int stat_chance = number_range( 1, 10 );

   if( stat_chance >= 3 )
      successful = TRUE;

      if( !successful )
      {
         send_to_char( "&RYou feel that you have wasted alot of energy for next to nothing...\r\n", ch );
         gain_power( ch, GET_PLGAIN(ch)/100 + 1, FALSE );;
         return;
      }

      send_to_char( "&GAfter hours of studying, you feel smarter.\r\n", ch );
      gain_power( ch, GET_PLGAIN(ch) / 4, FALSE );;
      trans_chance( ch );
     
 /*
  *    Chance for stats to increase
  */
    if ( stat_chance >= 7 && stat_chance <= 9)
     ki_increase( ch, FALSE );

    if ( stat_chance == 10 &&
         ch->perm_int < ( 20 + race_table[ch->race].int_plus ) )
     {
      send_to_char( "&YYour intelligence has increased!\r\n", ch );
      ch->perm_int++;
     }
      return;
}

void do_meditate( CHAR_DATA *ch, char *argument )
{
 char arg[MAX_INPUT_LENGTH];
 bool successful = FALSE;

  strcpy( arg, "meditate");

   if( IS_NPC( ch ) )
      return;

   cost = cost_calc( ch, cost );

   if ( IS_ANDROID( ch ) )
    {        
     send_to_char( "Training your mechanical body would be pointless.\r\n", ch );
     return;
    }

   if ( ch->move < cost )
    {        
     send_to_char( "You feel much to tired to do any exercises.\r\n", ch );
     return;
    }

   if ( IS_ISOLATION( ch ) )
    {        
     send_to_char( "It is hard to exercise in an isolation chamber.\r\n", ch );
     return;
    }

   switch ( ch->substate )
   {
      default:

         if( !IS_AWAKE( ch ) )
         {
            send_to_char( "In your dreams, or what?\r\n", ch );
            return;
         }

         send_to_char( "&GYou relax your mind and body and begin to meditate.\r\n", ch );
         ch->move -= cost;
         add_timer( ch, TIMER_DO_FUN, 2, do_meditate, 1 );
         ch->dest_buf = str_dup( arg );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy(arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou fail to complete your training.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;
   int stat_chance = number_range( 1, 10 );

   if( stat_chance >= 3 )
      successful = TRUE;

      if( !successful )
      {
         send_to_char( "&RYou feel that you have wasted alot of energy for next to nothing...\r\n", ch );
         gain_power( ch, GET_PLGAIN(ch)/100 + 1, FALSE );;
         return;
      }

      send_to_char( "&GAfter much meditation you feel more connected with surroundings.\r\n", ch );
      gain_power( ch, GET_PLGAIN(ch) / 4, FALSE );;
      trans_chance( ch );
     
 /*
  *    Chance for stats to increase
  */
    if ( stat_chance >= 7 && stat_chance <= 9)
     ki_increase( ch, FALSE );

    if ( stat_chance == 10 &&
         ch->perm_wis < ( 20 + race_table[ch->race].wis_plus ) )
     {
      send_to_char( "&YYour wisdom has increased!\r\n", ch );
      ch->perm_wis++;
     }
      return;
}

void do_jog( CHAR_DATA *ch )
{
   
    if ( IS_NPC(ch) )
    {
        send_to_char( "Huh?\r\n", ch );
        return;
    }
   
   if ( IS_ANDROID( ch ) )
    {        
     send_to_char( "Training your mechanical body would be pointless.\r\n", ch );
     return;
    }

    if( !IS_AWAKE( ch ) )
    {
            send_to_char( "In your dreams, or what?\r\n", ch );
            return;
     }

    if ( IS_SET( ch->pcdata->flags, PCFLAG_JOG ) )
    {
        REMOVE_BIT( ch->pcdata->flags, PCFLAG_JOG );

        send_to_char( "&GYou are no longer jogging.\r\n", ch );
        act( AT_GREEN, "&G$n stops jogging.", ch, NULL, NULL, TO_ROOM );
    }
    else
    {
        SET_BIT( ch->pcdata->flags, PCFLAG_JOG );

        send_to_char( "&GYou are now jogging.\r\n", ch );
        act( AT_GREY, "&G$n starts to jog.", ch, NULL, NULL, TO_ROOM );
    }
 return;
}

