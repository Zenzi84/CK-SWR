/*
                               Celestial Knights
                                  dbskills.c
                            Benjamin 'Tzu' Peters

     Module for  various CKMud related abilities/commands
*/
#include <math.h>
#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "mud.h"


/* Local functions */
void ssj_syntax args( ( CHAR_DATA *ch ) );
void trans_syntax args( ( CHAR_DATA *ch ) );
void disp_levels args( ( CHAR_DATA * ch, int race, int ability, int main_abil, int str, int spd, int wis, int intel, int con, int cha, int lck, int ene  ) );



void do_showrace( CHAR_DATA *ch, char *argument )
{
 char arg[MAX_INPUT_LENGTH];
 int str = 20, spd = 20, wis = 20, intel = 20, con = 20, cha = 20, lck =20, ene = 20;
 int main_abil, ability, race;

 one_argument( argument, arg );

 if ( IS_NPC( ch ) )
  return;


 if ( arg[0] == '\0' )
 {
    ch_printf( ch, "Race       STR   SPD   CON   INT   WIS   CHA   LCK   ENE\r\n" );

  for( race = 0; race < MAX_RACE; race++ )
   {
    ch_printf( ch, "%-10s:%-3d   %-3d   %-3d   %-3d   %-3d   %-3d   %-3d   %-3d\r\n",
     npc_race[race],
     (20+race_table[race].str_plus ),
     (20+race_table[race].dex_plus ),
     (20+race_table[race].con_plus ),
     (20+race_table[race].int_plus ),
     (20+race_table[race].wis_plus ),
     (20+race_table[race].cha_plus ),
     (8+race_table[race].lck_plus ),
     (20+race_table[race].frc_plus ) );
  }
  return;
 }

 if ( !str_cmp( arg, "human" ) )
 {
  race = RACE_HUMAN;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis,  intel, con, cha, lck, ene );
   return;
  }

 if ( !str_cmp( arg, "saiyajin" ) )
 {
  race = RACE_SAIYAJIN;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis, intel, con, cha, lck, ene );
   return;
  }

 if ( !str_cmp( arg, "halfbreed" ) )
 {
  race = RACE_HALFBREED;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis, intel, con, cha, lck, ene );
   return;
  }

 if ( !str_cmp( arg, "namek" ) )
 {
  race = RACE_NAMEK;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis, intel, con, cha, lck, ene );
   return;
  }

 if ( !str_cmp( arg, "android" ) )
 {
  race = RACE_ANDROID;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis, intel, con, cha, lck, ene );
   return;
  }

 if ( !str_cmp( arg, "icer" ) )
 {
  race = RACE_ICER;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis, intel, con, cha, lck, ene );
   return;
  }

 if ( !str_cmp( arg, "kaio" ) )
 {
  race = RACE_KAIO;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis, intel, con, cha, lck, ene );
   return;
  }

 if ( !str_cmp( arg, "majin" ) )
 {
  race = RACE_MAJIN;
  
   disp_levels( ch, race, ability, main_abil, str, spd, wis, intel, con, cha, lck, ene );
   return;
  }

 return;
}

void disp_levels( CHAR_DATA * ch, int race, int ability, int main_abil, int str, int spd, int wis, int intel, int con, int cha, int lck, int ene )
{
  str = 20+race_table[race].str_plus;
  spd = 20+race_table[race].dex_plus;
  wis = 20+race_table[race].wis_plus;
  intel = 20+race_table[race].int_plus;
  con = 20+race_table[race].con_plus;
  cha = 20+race_table[race].cha_plus;
  lck = 8+race_table[race].lck_plus;
  ene = 20+race_table[race].frc_plus;

   set_char_color( AT_YELLOW, ch );
   ch_printf( ch, "---------- %-10s---------\r\n", npc_race[race] );
   for( main_abil = 0; main_abil < MAX_ABILITY; main_abil++ )
    {
   set_char_color( AT_CYAN, ch );
   ch_printf( ch, "-----%-15s------\r\n", ability_name[main_abil] );
   set_char_color( AT_WHITE, ch );
    for( ability = 0; ability < MAX_ABILITY; ability++ )
     {
          ch_printf( ch, "%-15s   Max: %-3d\r\n",
                     ability_name[ability], 
      calc_max_level( race , ability, main_abil, str, spd, wis, intel, con, cha, lck, ene ) );
      continue; 
     }
    }
 return;
}

/*
 * Global multiplier to reward mortals
 */
void do_setbonus( CHAR_DATA *ch, char *argument )
{
 char buf[MAX_INPUT_LENGTH];
 char arg1[MAX_INPUT_LENGTH];
 char arg2[MAX_INPUT_LENGTH];
 int value = 0;

  argument = one_argument( argument, arg1 );
  argument = one_argument( argument, arg2 );

   if ( IS_NPC(ch) || !IS_IMMORTAL(ch)  )
    {
     send_to_char( "Huh?.\r\n", ch );
     return;
    }
     
 if ( arg1[0] == '\0' )
  {
    send_to_char( "Syntax: SetBonus:                            \r\n", ch );
    send_to_char( "                 plgain off / 2 / 3 / 4 / 5  \r\n", ch );
    send_to_char( "                 zenni  off / 2 / 3 / 4 / 5  \r\n", ch );
    send_to_char( "                 reset / all                 \r\n", ch );
    return;
  }

 if ( !str_cmp( arg1, "reset" ) )
  {
    PL_BONUS   = 1;
    ZEN_BONUS  = 1;
    BONUS_TIME = -1;
    sprintf( buf, "All bonus modifiers have expired" );
    do_global_mess( ch, buf );
    return;
  }

 if ( !str_cmp( arg1, "all" ) )
  {
  if ( arg2[0] == '\0' )
   {
     send_to_char( "Syntax: SetBonus:                            \r\n", ch );
     send_to_char( "                 plgain off / 2 / 3 / 4 / 5  \r\n", ch );
     send_to_char( "                 zenni  off / 2 / 3 / 4 / 5  \r\n", ch );
     send_to_char( "                 reset / all                 \r\n", ch );
     return;
   }

    value = atoi( arg2 );

  if ( value < 1 || value > 5 )
   {
    send_to_char( "Value range for bonuses is 1 - 5.\r\n", ch );
    return;
   }
  

    BONUS_TIME = 60;
    PL_BONUS   = value;
    ZEN_BONUS  = value;
    sprintf( buf, "A global %dx PL and Zenni bonus has been put into affect by %s for 60 mimutes", value, ch->name );
    do_global_mess( ch, buf );
    return;
  }

 if ( !str_cmp( arg1, "plgain" ) )
  {
  if ( arg2[0] == '\0' )
   {
     send_to_char( "Syntax: SetBonus:                            \r\n", ch );
     send_to_char( "                 plgain off / 2 / 3 / 4 / 5  \r\n", ch );
     send_to_char( "                 zenni  off / 2 / 3 / 4 / 5  \r\n", ch );
     send_to_char( "                 reset / all                 \r\n", ch );
     return;
   }

  if ( !str_cmp( arg2, "off" ) )
  {
    PL_BONUS  = 1;

   if ( ZEN_BONUS <= 1 )
    BONUS_TIME = -1;

    sprintf( buf, "All bonus modifiers have expired" );
    do_global_mess( ch, buf );
    return;
  }
    value = atoi( arg2 );

  if ( value < 1 || value > 5 )
   {
    send_to_char( "Value range for PL bonus is 1 - 5.\r\n", ch );
    return;
   }
  

    BONUS_TIME = 60;
    PL_BONUS  = value;
    sprintf( buf, "A global %dx PL bonus has been put into affect by %s for 60 mimutes", value, ch->name );
    do_global_mess( ch, buf );
    return;
  }

 if ( !str_cmp( arg1, "zenni" ) )
  {
  if ( arg2[0] == '\0' )
   {
     send_to_char( "Syntax: SetBonus:                            \r\n", ch );
     send_to_char( "                 plgain off / 2 / 3 / 4 / 5  \r\n", ch );
     send_to_char( "                 zenni  off / 2 / 3 / 4 / 5  \r\n", ch );
     send_to_char( "                 reset / all                 \r\n", ch );
     return;
   }

  if ( !str_cmp( arg2, "off" ) )
  {
    ZEN_BONUS  = 1;

   if ( PL_BONUS <= 1 )
    BONUS_TIME = -1;

    sprintf( buf, "All bonus modifiers have expired" );
    do_global_mess( ch, buf );
    return;
  }
    value = atoi( arg2 );

  if ( value < 1 || value > 5 )
   {
    send_to_char( "Value range for PL bonus is 1 - 5.\r\n", ch );
    return;
   }

    BONUS_TIME = 60;
    ZEN_BONUS  = value;
    sprintf( buf, "A global %dx Zenni bonus has been put into affect by %s for 60 mimutes", value, ch->name );
    do_global_mess( ch, buf );
    return;
  }

    send_to_char( "Syntax: SetBonus:                            \r\n", ch );
    send_to_char( "                 plgain off / 2 / 3 / 4 / 5  \r\n", ch );
    send_to_char( "                 zenni  off / 2 / 3 / 4 / 5  \r\n", ch );
    send_to_char( "                 reset / all                 \r\n", ch );
 return;
}



/* Only show syntax for the forms you know. */
void trans_syntax( CHAR_DATA *ch )
{
    if ( ch->pcdata->learned[gsn_transform1] > 0 && ch->pcdata->learned[gsn_transform2] <= 0 )
     send_to_char( "&WSyntax: TRANSFORM first/revert.\r\n", ch );
    else if ( ch->pcdata->learned[gsn_transform2] > 0 && ch->pcdata->learned[gsn_transform3] <= 0 )
     send_to_char( "&WSyntax: TRANSFORM first/second/revert.\r\n", ch );
    else if ( ch->pcdata->learned[gsn_transform3] > 0 && ch->pcdata->learned[gsn_transform4] <= 0 )
     send_to_char( "&WSyntax: TRANSFORM first/second/third/revert.\r\n", ch );
    else if ( ch->pcdata->learned[gsn_transform4] > 0 )
     send_to_char( "&WSyntax: TRANSFORM first/second/fourth/revert.\r\n", ch );

  return;
}

void ssj_syntax( CHAR_DATA *ch )
{
   if ( ch->race == RACE_SAIYAJIN )
    {
    if ( ch->pcdata->learned[gsn_ssj] > 0 && ch->pcdata->learned[gsn_ssj2] <= 0 )
     send_to_char( "&WSyntax: SSJ first/revert.\r\n", ch );
    else if ( ch->pcdata->learned[gsn_ssj2] > 0 && ch->pcdata->learned[gsn_ssj3] <= 0 )
     send_to_char( "&WSyntax: SSJ first/second/revert.\r\n", ch );
    else if ( ch->pcdata->learned[gsn_ssj3] > 0 )
     send_to_char( "&WSyntax: SSJ first/second/third/revert.\r\n", ch );
    }

   if ( ch->race == RACE_HALFBREED )
    {
    if ( ch->pcdata->learned[gsn_hssj] > 0 && ch->pcdata->learned[gsn_hssj2] <= 0 )
     send_to_char( "&WSyntax: HSSJ first/revert.\r\n", ch );
    else if ( ch->pcdata->learned[gsn_hssj2] > 0 )
     send_to_char( "&WSyntax: HSSJ first/second/revert.\r\n", ch );
    }
 return;
}

void do_notcast( CHAR_DATA *ch, char *argument )
{
  send_to_char("&WSyntax: focus 'skill name' target.\r\n", ch );
  return;
}

void do_camp( CHAR_DATA *ch, char *argument )
{
   char arg[MAX_INPUT_LENGTH];
   char buf[MAX_STRING_LENGTH];
   int level, schance, vnum = 30;
   bool checksupply;
   OBJ_DATA *obj;
  // OBJ_DATA *material = NULL;

  
  strcpy( arg, "&RA campfire" );
 
  if ( IS_NPC( ch ) )
      return;
  
   switch ( ch->substate )
   {
      default:
       checksupply = TRUE;  // elimating the need for supllies

        if ( !IS_MAP( ch ) )
         {
          send_to_char("You can only setup camp on the world map.\r\n", ch );
          return;
        }

         for( obj = ch->last_carrying; obj; obj = obj->prev_content )
         {
            if( obj->item_type == ITEM_CAMP_SUPPLIES)
               checksupply = TRUE;
         }

         if( !checksupply )
         {
            send_to_char( "&RYou need some supplies to setup a camp.\r\n", ch );
            return;
         }

         schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_camp] );
         if( number_percent(  ) < schance )
         {
            send_to_char( "&GYou begin to slowly setup a camp.\r\n", ch );
            act( AT_PLAIN, "$n takes some supplies and begins to set up camp", ch, NULL, NULL, TO_ROOM );
            add_timer( ch, TIMER_DO_FUN, 1, do_camp, 1 );
            ch->dest_buf = str_dup( arg );
            return;
         }
         send_to_char( "&RYou can't figure out what to do.\r\n", ch );
         learn_from_failure( ch, gsn_camp );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy( arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou are interupted and fail to finish your work.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;

   level = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_camp] );

   checksupply = TRUE;

   for( obj = ch->last_carrying; obj; obj = obj->prev_content )
   {
      if( obj->item_type == ITEM_CAMP_SUPPLIES && checksupply == FALSE )
      {
         checksupply = TRUE;
//         separate_obj( obj );
//         obj_from_char( obj );
//         material = obj;
      }
   }

   schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_camp] );

   if( number_percent(  ) > schance * 2 || ( !checksupply) )
   {
      send_to_char( "&RYou end up snapping several of the tent poles and destroy your supplies.\r\n", ch );
      learn_from_failure( ch, gsn_camp );
      return;
   }

   obj = create_object(get_obj_index(vnum), 0);

   obj->item_type = ITEM_CAMP;

  
   obj->level = level;
   STRFREE( obj->name );
   strcpy( buf, arg );
   obj->name = STRALLOC( buf );
   STRFREE( obj->short_descr );
   obj->short_descr = STRALLOC( buf );
   STRFREE( obj->description );
   strcat( buf, " looks rather inviting here.&w" );
   obj->description = STRALLOC( buf );
   obj->value[0] = level;
   obj->value[1] = 0;
   obj->value[2] = 0;
   obj->value[3] = 10;
   obj->timer = ( level/10 + 1);
   obj->cost *= level;
   REMOVE_BIT( obj->wear_flags, ITEM_TAKE );
  
   obj = obj_to_room( obj, ch->in_room );

   send_to_char( "&GYou finish setting up camp and sit by the fire.&w\r\n", ch );
   act( AT_PLAIN, "$n finishes setting up camp and sits by the fire", ch, NULL, argument, TO_ROOM );
   ch->position = POS_SITTING;
  
   {
      long xpgain;

      xpgain =
         UMIN( 500,
               ( exp_level( ch->skill_level[ENGINEERING_ABILITY] + 1 ) -
                 exp_level( ch->skill_level[ENGINEERING_ABILITY] ) ) );
      gain_exp( ch, xpgain, ENGINEERING_ABILITY );
      ch_printf( ch, "You gain %d engineering experience.", xpgain );
   }
   learn_from_success( ch, gsn_camp);
 return;
}

void do_setgravity( CHAR_DATA *ch, char *argument )
{
   char arg[MAX_INPUT_LENGTH];
   bool gravitron = FALSE;
   OBJ_DATA *obj, *obj_next;
   int value;

  one_argument( argument, arg );
 
  if ( IS_NPC( ch ) )
      return;
  
   for( obj = ch->in_room->first_content; obj; obj = obj_next )
      {
         obj_next = obj->next_content;
         if( obj->item_type != ITEM_GRAVITRON )
            continue;
         gravitron = TRUE;
      }
 
    if (!gravitron)
     {
       send_to_char("There doesn't appear to be a gravitron in this room.\r\n", ch);
       return;
     }
 
  if ( arg[0] == '\0' )
  {
     send_to_char("Syntax: SetGravity 1 - 1000\r\n'", ch);
     return;
  }
 
  value = atoi( arg );

  if ( value < 1 || value > 1000 )
   {
     set_char_color( AT_WHITE, ch );
     send_to_char("Invalid Range... ...\r\n'", ch);
     send_to_char("Syntax: SetGravity 1 - 1000\r\n'", ch);
    return;
   }

/*
  if ( value > 100 && IS_SHIP( ch ) )
   {
     set_char_color( AT_WHITE, ch );
     send_to_char("Die to the nature of spacecraft, range is limited to no more then 100x earth gravity.\r\n'", ch);
     return;
   }
*/
    for( obj = ch->in_room->first_content; obj; obj = obj_next )
      {
         obj_next = obj->next_content;
         if( obj->item_type != ITEM_GRAVITRON )
            continue;

        if( obj->item_type == ITEM_GRAVITRON )
         {
          obj->timer = 10;
          break;
         }
      }

  ch->in_room->gravity = value;
  set_char_color( AT_RED, ch );
  ch_printf( ch,"You adjust the dial on the gravitron to %dx earth gravity", value);
  act( AT_RED, "$n adjusts the dial on the gravitron.\r\n", ch, NULL, NULL, TO_ROOM );

 return;
}

void do_suppress( CHAR_DATA *ch, char *argument )
{
   short percent, value;
   char arg[MAX_INPUT_LENGTH];
  
   one_argument( argument, arg);

   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_suppress] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
  }
  
   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_suppress];

  
 if ( argument[0] == '\0' )
  {
   if ( GET_SUPPRESS( ch ) > 0 )
    {
     act( AT_MAGIC, "You stop concentrating on suppressing your powerlevel.\r\n", ch, NULL, NULL, TO_CHAR );
     act( AT_MAGIC, "You sense $n's powerlevel suddenly increases'.\r\n", ch, NULL, NULL, TO_ROOM );
      GET_SUPPRESS( ch ) = 0;
     return;
    }
    
     set_char_color( AT_WHITE, ch );
     send_to_char( "Syntax: Suppress(to release)\r\n", ch );
     send_to_char( "Syntax: Suppress 1-100\r\n", ch );
     send_to_char( "You are not currently suppresing your powerlevel.\r\n", ch );
     return;  
  }

   if ( GET_SUPPRESS( ch ) > 0 )
    {
     set_char_color( AT_WHITE, ch );
     send_to_char( "You are already suppressing your powerlevel.\r\n", ch );
     return;  
    }
  
    value = atoi( arg );

  if ( value < 1 || value > 99 )
   {
     set_char_color( AT_WHITE, ch );
     send_to_char( "Syntax: Suppress(to release)\r\n", ch );
     send_to_char( "Syntax: Suppress 1-100\r\n", ch );
     send_to_char( "Value range for suppression 1 - 99.\r\n", ch );
    return;
   }
  
   if( number_percent( ) > percent )
   {
      set_char_color( AT_WHITE, ch );
      send_to_char( "You try to suppress your powerlevel, but lose your concen.\r\n", ch );
      learn_from_failure( ch, gsn_suppress );
      return;
   }

     act( AT_MAGIC, "You concentrate on suppressing your powerlevel.\r\n", ch, NULL, NULL, TO_CHAR );
     act( AT_MAGIC, "You sense $n's powerlevel suddenly decreases'.\r\n", ch, NULL, NULL, TO_ROOM );
     GET_SUPPRESS( ch ) = ( (double)(ch->powerlevel) / 100 ) * value ;
    
   learn_from_success( ch, gsn_suppress );
 return;
}

void do_powerup( CHAR_DATA *ch, char *argument )
{
   short percent;
   float max_powerup = 1.25;

   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_powerup] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_powerup];

 /* Different races have different maximum powerups */
   if ( ch->race == RACE_HUMAN )
    max_powerup = 3.5;
   if ( ch->race == RACE_HALFBREED )
    max_powerup = 1.5;

   if ( GET_POWERUP( ch ) < 1.0 )
    GET_POWERUP(ch) = 1.0;

 if ( argument[0] == '\0' )
  {
   if ( GET_POWERUP( ch ) >= max_powerup )
    {
     send_to_char( "Syntax: Powerup max/revert.\r\n", ch );
     send_to_char( "You are already powered up to your maximum.\r\n", ch );
     return;
    }

   if( number_percent( ) > percent )
   {
      send_to_char( "You clench your fists and try to powerup, but do little more than just scream.\r\n", ch );
      learn_from_failure( ch, gsn_powerup );
      return;
   }

   act( AT_MAGIC, "Your ki aura bursts outward as you clench your fists and powerup.\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_MAGIC, "$n ki aura bursts outward as they clench their fists and powerup.\r\n", ch, NULL, NULL, TO_ROOM );

   GET_POWERUP(ch) += 0.05;
   learn_from_success( ch, gsn_powerup );
  }

 if ( !str_cmp( argument, "revert" ) )
  {
   if ( GET_POWERUP( ch ) <= 1.0 )
    {
     send_to_char( "Syntax: Powerup max/revert.\r\n", ch );
     send_to_char( "You are already powered down.\r\n", ch );
     return;
    }

   if( number_percent( ) > percent )
   {
      send_to_char( "You try to relax and power down, but just can't quite get it.\r\n", ch );
      learn_from_failure( ch, gsn_powerup );
      return;
   }

   act( AT_MAGIC, "Your aura fades away as you relax and power down.\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_MAGIC, "$n's ki aura fades away as they power down.\r\n", ch, NULL, NULL, TO_ROOM );

   GET_POWERUP(ch) = 1.0;
  }

 if ( !str_cmp( argument, "max" ) )
  {
   if ( GET_POWERUP( ch ) >= max_powerup )
    {
     send_to_char( "Syntax: Powerup max/revert.\r\n", ch );
     send_to_char( "You are already powered up to your maximum.\r\n", ch );
     return;
    }


   if( number_percent( ) > percent )
   {
      send_to_char( "You clench your fists and try to powerup, but do little more than just scream.\r\n", ch );
      learn_from_failure( ch, gsn_powerup );
      return;
   }

   act( AT_MAGIC, "The ground shakes beneath you as you powerup to your maximum!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_MAGIC, "$n ki aura bursts violently and the ground shakes beneath you as the powerup to their maximum!\r\n", ch, NULL, NULL, TO_ROOM );

   GET_POWERUP(ch) = max_powerup;
   learn_from_success( ch, gsn_powerup );
  }
 return;
}

/* Namekian / Majin regen skill */
void do_regenerate( CHAR_DATA *ch, char *argument )
{
 int sn;

 if ( IS_NPC( ch ) )
   return;

 if ( !IS_NAMEK( ch ) && !IS_MAJIN( ch ) )
  {
   send_to_char( "You do not know how to do that.\r\n", ch );
   return;
  }

 if ( ch->fighting )
  {
   ch_printf( ch, "You are a little busy right now...\r\n.");
   return;
  }

 if ( IS_NAMEK( ch ) )   sn = gsn_regenerate;
 if ( IS_MAJIN( ch ) )   sn = gsn_rejuvenate;


 if ( !IS_NPC(ch) && ch->pcdata->learned[sn] <= 0 )
  {
   send_to_char( "You do not know how to do that.\r\n", ch );
   return;
  }

 if ( IS_SET( ch->pcdata->flags, PCFLAG_REGEN ) )
  {
   ch_printf( ch ,"&GYou stop focusing on regenerating your body.&w\r\n" );
   REMOVE_BIT( ch->pcdata->flags, PCFLAG_REGEN );
   return;
  }

 if ( ch->hit >= ch->max_hit )
  {
   send_to_char( "Your body is already fully regenerated.\r\n", ch );
   return;
  }
          
 if ( !IS_SET( ch->pcdata->flags, PCFLAG_REGEN ) )
  {
   ch_printf( ch ,"&GYou narrow your focus and use your ki to regenerate your body.&w\r\n" );
   SET_BIT( ch->pcdata->flags, PCFLAG_REGEN );
   return;
  }

 return;
}

/* Saiya-jin and Halfies only, halfies will use hssj command */
void do_ssj( CHAR_DATA *ch, char *argument )
{
   short percent;

   if ( ch->race != RACE_SAIYAJIN  )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }

   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_ssj] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
          
   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_ssj];

   if ( GET_TRANS( ch ) < 1.0 )
    GET_TRANS(ch) = 1.0;

 if ( argument[0] == '\0' )
  {
    ssj_syntax( ch );
    return;
  }

 if ( !str_cmp( argument, "revert" ) )
  {
   if ( GET_TRANS( ch ) <= 1.0 )
    {
     ssj_syntax( ch );
     send_to_char( "You are not in any form.\r\n", ch );
     return;
    }

   act( AT_YELLOW, "Your aura fades away as you revert from SSJ.\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n ki aura fades away and their hair and eyes return to normal\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 1.0;
  }

 if ( !str_cmp( argument, "first" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_ssj] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 1 )
    {
     ssj_syntax( ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   act( AT_YELLOW, "Your hair turns a bright yellow and eyes a vibrant blue, your aura bursts violently around you as you turn Super Saiyajin!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's hair turns a bright yellow and their eyes a vibrant blue, their aura bursts violently around them as they achieve Super Saiyajin.\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 1 + ((double)percent/100);
  }

 if ( !str_cmp( argument, "second" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_ssj] <= 0 )
    {
     send_to_char( "You do not even know how to go super saiyajin yet.\r\n", ch );
     return;
    }
     
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_ssj2] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 2 )
    {
     ssj_syntax( ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_ssj2];

   act( AT_YELLOW, "Your aura bursts outward and crackles with lightning around you as you turn Super Saiyajin 2!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's aura bursts out and crackles with lightning as they achieve Super Saiyajin 2!\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 2 + ( (double)percent / 100 );
  }

 if ( !str_cmp( argument, "third" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_ssj] <= 0 )
    {
     send_to_char( "You do not even know how to go super saiyajin yet.\r\n", ch );
     return;
    }
     
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_ssj2] <= 0 )
    {
     send_to_char( "You do not even know how to go super saiyajin 2 yet.\r\n", ch );
     return;
    }
     
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_ssj3] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 3 )
    {
     ssj_syntax( ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_ssj3];

   act( AT_YELLOW, "Your hair grows out waist length, your eyebrows disappear, and your aura fades as you channel your energy and turn Super Saiyajin 3!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's hair grows out to their waist and their eyebrows disappear, their aura fades out as the channel their energy and achieve Super Saiyajin 3!\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 3 + ( (double)percent / 100 );
  }


  return;
}

void do_hssj( CHAR_DATA *ch, char *argument )
{
   short percent;

   if ( ch->race != RACE_HALFBREED )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }

   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_hssj] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
          
   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_hssj];

   if ( GET_TRANS( ch ) < 1.0 )
    GET_TRANS(ch) = 1.0;

 if ( argument[0] == '\0' )
  {
    ssj_syntax( ch );
    return;
  }

 if ( !str_cmp( argument, "revert" ) )
  {
   if ( GET_TRANS( ch ) <= 1.0 )
    {
     ssj_syntax( ch );
     send_to_char( "You are not in any form.\r\n", ch );
     return;
    }

   act( AT_YELLOW, "Your aura fades away as you revert from SSJ.\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n ki aura fades away and their hair and eyes return to normal\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 1.0;
  }

 if ( !str_cmp( argument, "first" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_hssj] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 1 )
    {
     ssj_syntax( ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   act( AT_YELLOW, "Your hair turns a bright yellow and eyes a vibrant blue, your aura bursts violently around you as you turn Super Saiyajin!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's hair turns a bright yellow and their eyes a vibrant blue, their aura bursts violently around them as they achieve Super Saiyajin.\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 1 + ( (double)percent / 100 );
  }

 if ( !str_cmp( argument, "second" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_hssj] <= 0 )
    {
     send_to_char( "You do not even know how to go super saiyajin yet.\r\n", ch );
     return;
    }
     
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_hssj2] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 2 )
    {
     ssj_syntax( ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_hssj2];

   act( AT_YELLOW, "Your aura bursts outward and crackles with lightning around you as you turn Super Saiyajin 2!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's aura bursts out and crackles with lightning as they achieve Super Saiyajin 2!\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 2 + ( (double)percent / 100 );
  }

  return;
}

/* Transformations for other races */
void do_transform( CHAR_DATA *ch, char *argument )
{
  short percent;

   if ( ch->race != RACE_ICER )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }

   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_transform1] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
          
   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_transform1];

   if ( GET_TRANS( ch ) < 1.0 )
    GET_TRANS(ch) = 1.0;

 if ( argument[0] == '\0' )
  {
    trans_syntax( ch );
    return;
  }

 if ( !str_cmp( argument, "revert" ) )
  {
   if ( GET_TRANS( ch ) <= 1.0 )
    {
     trans_syntax( ch );
     send_to_char( "You are not in any form.\r\n", ch );
     return;
    }

   act( AT_YELLOW, "Your aura fades away as you revert from your form.\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n ki aura fades away as they power down from their form.\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 1.0;
  }

 if ( !str_cmp( argument, "first" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_transform1] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 1 )
    {
     trans_syntax( ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   act( AT_YELLOW, "Your aura bursts outward as you achieve a superior form!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's aura bursts outward as they achieve a superior form\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 1 + ( (double)percent / 100 );
  }

 if ( !str_cmp( argument, "second" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_transform2] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 2 )
    {
     trans_syntax( ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_transform2];

   act( AT_YELLOW, "Your aura bursts outward as you achieve a superior form!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's aura bursts outward as they achieve a superior form\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 2 + ( (double)percent / 100 );
  }

   if ( !str_cmp( argument, "third" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_transform3] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 3 )
    {

     send_to_char( "&WSyntax: Transform first/second/third/fourth/revert.\r\n", ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_transform3];

   act( AT_YELLOW, "Your aura bursts outward as you achieve a superior form!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's aura bursts outward as they achieve a superior form\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 3 + ( (double)percent / 100 );
  }

   if ( !str_cmp( argument, "fourth" ) )
  {
   if ( !IS_NPC(ch) && ch->pcdata->learned[gsn_transform4] <= 0 )
    {
     send_to_char( "You do not know how to do that.\r\n", ch );
     return;
    }
     
   if ( GET_TRANS( ch ) > 4 )
    {

     send_to_char( "&WSyntax: Transform first/second/third/fourth/revert.\r\n", ch );
     send_to_char( "You have already achieved that form.\r\n", ch );
     return;
    }

   percent = IS_NPC( ch ) ? 80 : ch->pcdata->learned[gsn_transform4];

   act( AT_YELLOW, "Your aura bursts outward as you achieve a superior form!\r\n", ch, NULL, NULL, TO_CHAR );
   act( AT_YELLOW, "$n's aura bursts outward as they achieve a superior form\r\n", ch, NULL, NULL, TO_ROOM );

   GET_TRANS(ch) = 4 + ( (double)percent / 100 );
  }

  return;
}

void do_cut_wood( CHAR_DATA * ch )
{
 return;
}

void do_mine_ore( CHAR_DATA * ch, char *argument )
{
   char arg[MAX_INPUT_LENGTH];
   char buf[MAX_STRING_LENGTH];
   int level, schance;
   OBJ_DATA *obj, *pickaxe;

   if ( !LEARNED( ch, gsn_mine_ore) )   
    {
     set_char_color( AT_PLAIN, ch );
     send_to_char("Huh?\r\n", ch );
     return;
    }
   
   if ( !IS_MAP( ch ) )
    {
     set_char_color( AT_RED, ch );
     send_to_char( "You must be on the world map to mine for ore.\r\n", ch );
     return;
    }

   if ( ch->move < 50 && !IS_ANDROID( ch ) )
    {
     set_char_color( AT_MAGIC, ch );
     send_to_char( "You are to tired to swing a pickaxe...\r\n", ch );
     return;
    }

   switch ( ch->in_room->sector_type )
    {
     default:
      set_char_color( AT_RED, ch );
      send_to_char( "You can only mine for ore in the mountains, hills, plains, desert, and shallow water.\r\n", ch );
      return;
      break;
     case SECT_MOUNTAIN:
     case SECT_HILLS:
     case SECT_WATER_SWIM:
     case SECT_FIELD:
     case SECT_DESERT:
     break;	
    }
      
   if ( ( pickaxe = get_eq_char( ch, WEAR_HOLD ) ) == NULL )
    {
     set_char_color( AT_RED, ch );
     send_to_char( "You need to be holding a pickaxe in order to mine for ore.\r\n", ch );
     return;
    }
   
   if ( pickaxe->item_type != ITEM_PICKAXE )
    {
     set_char_color( AT_RED, ch );
     ch_printf( ch ,"You try to use a %s to mine for ore, but it just smashes it to pieces.\r\n", pickaxe->short_descr );
     separate_obj( pickaxe );
     obj_from_char( pickaxe );
     return;
    }

   switch ( ch->substate )
   {
      default:
         schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_mine_ore] );
         if( number_percent(  ) < schance )
         {
            set_char_color( AT_GREEN, ch );
            send_to_char( "You start mining for ore.\r\n", ch );
            act( AT_PLAIN, "$n grabs a pickaxe and starts mining for ore.", ch, NULL, NULL, TO_ROOM );

            if ( ch->move >= 50 && !IS_ANDROID( ch ) )
             ch->move -= 50;

            add_timer( ch, TIMER_DO_FUN, 1, do_mine_ore, 1 );
            ch->dest_buf = str_dup( arg );
            return;
         }

         set_char_color( AT_RED, ch );
         send_to_char( "You scratch your head in confusion, unsure where to start.\r\n", ch );
         learn_from_failure( ch, gsn_mine_ore );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy( arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou are interupted and fail to finish your work.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;

   level = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_mine_ore] );
   schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_mine_ore] );

   if ( ( pickaxe = get_eq_char( ch, WEAR_HOLD ) ) != NULL )
    {
     if ( pickaxe->value[1] > 0 )
       pickaxe->value[1]--;
     if ( pickaxe->value[1] == 0 )
      {
       set_char_color( AT_RED, ch );
       ch_printf( ch ,"Your pickaxe falls apart from extensive use.\r\n", pickaxe->short_descr );
       separate_obj( pickaxe );
       obj_from_char( pickaxe );
      }
     
    }
   if( number_percent(  ) > schance * 2  )
   {
      set_char_color( AT_RED, ch );
      send_to_char( "You end your search, frustrated with your inability to locate ore.\r\n", ch );
      learn_from_failure( ch, gsn_mine_ore );
      return;
   }

   obj = create_object( get_obj_index( OBJ_VNUM_ORE ), 0 );

/*
 * 1  - 24  = Dirt
 * 25 - 64  = Stone
 * 65 - 99  = Iron
 *100 - 119 = Bronze
 *120 - 134 = Silver
 *135 - 144 = Gold
 *145 - 149 = Gem
 */

   int drop_rate = number_range( 1, 149 );
   int gem_pick = number_range(1, 100 );

  switch( ch->in_room->sector_type )
   {
    default:
     return;
     break;
    
    case SECT_MOUNTAIN:
     drop_rate = number_range( 1, 124 ) + ( LEARNED( ch, gsn_mine_ore ) / 4 );
     break;

    case SECT_WATER_SWIM:
     drop_rate = number_range( 50, 124 ) + ( LEARNED( ch, gsn_mine_ore ) / 4 );
     break;

    case SECT_FIELD:
     drop_rate = number_range( 1, 80 ) + ( LEARNED( ch, gsn_mine_ore ) / 4 );
     break;

    case SECT_HILLS:
     drop_rate = number_range( 20, 100 ) + ( LEARNED( ch, gsn_mine_ore ) / 4 );
     break;

    case SECT_DESERT:
     drop_rate = number_range( 25, 100 ) + ( LEARNED( ch, gsn_mine_ore ) / 4 );
     break;
   }

  if ( drop_rate > 0 )
   {
     obj->value[0] = ORE_DIRT;
     STRFREE( obj->name );
     sprintf( buf, "some dirt" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
   }
  if ( drop_rate > 24 )
   {
     obj->value[0] = ORE_STONE;
     STRFREE( obj->name );
     sprintf( buf, "some stone" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
   }
  if ( drop_rate > 64 )
   {
     obj->value[0] = ORE_IRON;
     STRFREE( obj->name );
     sprintf( buf, "a lump of iron" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
   }
  if ( drop_rate > 99 )
   {
     obj->value[0] = ORE_BRONZE;
     STRFREE( obj->name );
     sprintf( buf, "a lump of bronze" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
   }
  if ( drop_rate > 119 )
   {
     obj->value[0] = ORE_SILVER;
     STRFREE( obj->name );
     sprintf( buf, "a lump of silver" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
   }
  if ( drop_rate > 134 )
   {
     obj->value[0] = ORE_GOLD;
     STRFREE( obj->name );
     sprintf( buf, "a lump of gold" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
   }

/* Gem Pick
 *  1 - 24  = Zirconian
 * 24 - 39  = Onyx
 * 40 - 59  = Amber
 * 59 - 79  = Amethyst
 * 80 - 89  = Ruby
 * 90 - 94  = Emerald
 * 95 - 98  = Sapphire
 * 99 - 100 = Diamond
*/

  if ( drop_rate > 144 )  // Gem
   {
     obj->item_type = ITEM_CRYSTAL;

    if ( gem_pick > 0 )
     {
      obj->value[0] = GEM_ZIRCONIAN;
      STRFREE( obj->name );
      sprintf( buf, "a zirconian gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
    if ( gem_pick > 24 )
     {
      obj->value[0] = GEM_ONYX;
      STRFREE( obj->name );
      sprintf( buf, "a black onyx gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
    if ( gem_pick > 39 )
     {
      obj->value[0] = GEM_AMBER;
      STRFREE( obj->name );
      sprintf( buf, "a amber gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
    if ( gem_pick > 59 )
     {
      obj->value[0] = GEM_AMETHYST;
      STRFREE( obj->name );
      sprintf( buf, "a amethyst gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
    if ( gem_pick > 79 )
     {
      obj->value[0] = GEM_RUBY;
      STRFREE( obj->name );
      sprintf( buf, "a ruby gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
    if ( gem_pick > 89 )
     {
      obj->value[0] = GEM_EMERALD;
      STRFREE( obj->name );
      sprintf( buf, "a emerald gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
    if ( gem_pick > 94 )
     {
      obj->value[0] = GEM_SAPPHIRE;
      STRFREE( obj->name );
      sprintf( buf, "a sapphire gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
    if ( gem_pick > 97 )
     {
      obj->value[0] = GEM_DIAMOND;
      STRFREE( obj->name );
      sprintf( buf, "a diamond gem" );
      obj->name = STRALLOC( buf );
      STRFREE( obj->short_descr );
      obj->short_descr = STRALLOC( buf );
     }
   }

   STRFREE( obj->description );
   strcat( buf, " was dropped here." );
   obj->description = STRALLOC( buf );

  if ( obj->item_type == ITEM_ORE )
   obj->cost = ( obj->value[0] * 50 );

  if ( obj->item_type == ITEM_CRYSTAL )
   obj->cost = ( obj->value[0] * 250 );

   obj = obj_to_char( obj, ch );

   set_char_color( AT_GREEN, ch );
   ch_printf( ch, "After much searching you have found %s\r\n", obj->short_descr );
   act( AT_PLAIN, "$n finishes their search of the area and holds up some ore.", ch, NULL, NULL, TO_ROOM );

   {
      long xpgain;

      xpgain =
         UMIN( obj->cost * 5,
               ( exp_level( ch->skill_level[ENGINEERING_ABILITY] + 1 ) -
                 exp_level( ch->skill_level[ENGINEERING_ABILITY] ) ) );
      gain_exp( ch, xpgain, ENGINEERING_ABILITY );
      ch_printf( ch, "You gain %d engineering experience.", xpgain );
   }
   learn_from_success( ch, gsn_mine_ore );
 return;
}

void do_hunt_animal( CHAR_DATA * ch , char *argument )
{
   char arg[MAX_INPUT_LENGTH];
   char buf[MAX_STRING_LENGTH];
   int level, schance;
   MOB_INDEX_DATA *mob;
   CHAR_DATA *prey;

   if ( !LEARNED( ch, gsn_hunt) )   
    {
     set_char_color( AT_PLAIN, ch );
     send_to_char("Huh?\r\n", ch );
     return;
    }
   
   if ( !IS_MAP( ch ) )
    {
     set_char_color( AT_RED, ch );
     send_to_char( "You must be on the world map to hunt animals\r\n", ch );
     return;
    }

   if ( ch->move < 50 && !IS_ANDROID( ch ) )
    {
     set_char_color( AT_MAGIC, ch );
     send_to_char( "You are to tired to think about hunting...\r\n", ch );
     return;
    }

   switch ( ch->in_room->sector_type )
    {
     default:
      set_char_color( AT_RED, ch );
      send_to_char( "You can only hunt animals in the forest and plains.\r\n", ch );
      return;
      break;
     case SECT_FOREST:
     case SECT_FIELD:
     break;	
    }
      

   switch ( ch->substate )
   {
      default:
         schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_hunt] );
         if( number_percent(  ) < schance )
         {
            set_char_color( AT_GREEN, ch );
            send_to_char( "You begin waiting patiently for a animal to show up.\r\n", ch );
            act( AT_PLAIN, "$n looks as if they have begun a hunt.", ch, NULL, NULL, TO_ROOM );

            if ( ch->move >= 50 && !IS_ANDROID( ch ) )
             ch->move -= 50;

            add_timer( ch, TIMER_DO_FUN, 1, do_hunt_animal, 1 );
            ch->dest_buf = str_dup( arg );
            return;
         }

         set_char_color( AT_RED, ch );
         send_to_char( "You scratch your head in confusion, unsure where to start.\r\n", ch );
         learn_from_failure( ch, gsn_hunt );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy( arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou are interupted and fail to finish your hunt.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;

   level = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_hunt] );
   schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_hunt] );

   if( number_percent(  ) > schance * 2  )
   {
      set_char_color( AT_RED, ch );
      send_to_char( "You end your hunt, seeing nothing but birds and squirrels.\r\n", ch );
      learn_from_failure( ch, gsn_hunt );
      return;
   }

// You deleted the mob if this happens
   if ( ( mob = get_mob_index( MOB_VNUM_HUNT ) ) == NULL )
      return;

   int hunt_rate = number_range( 1, 6 );

  switch( ch->in_room->sector_type )
   {
    default:
     return;
     break;
    
    case SECT_FIELD:
     hunt_rate = number_range( 1, 4 );
     break;

    case SECT_FOREST:
     hunt_rate = number_range( 3, 6 );
     break;
   }

  if ( hunt_rate == 1 )
   {
     prey = create_mobile( mob );
     prey->race = HUNT_RABBIT;
     STRFREE( prey->name );
     sprintf( buf, "a rabbit" );
     prey->name = STRALLOC( buf );
     STRFREE( prey->short_descr );
     prey->short_descr = STRALLOC( buf );
     STRFREE( prey->description );
     strcat( buf, " is hopping around the plains here." );
     prey->long_descr = STRALLOC( buf );
   }
  if ( hunt_rate == 2 )
   {
     prey = create_mobile( mob );
     prey->race = HUNT_BOAR;
     STRFREE( prey->name );
     sprintf( buf, "a boar" );
     prey->name = STRALLOC( buf );
     STRFREE( prey->short_descr );
     prey->short_descr = STRALLOC( buf );
     STRFREE( prey->description );
     strcat( buf, " is eating some grass here." );
     prey->long_descr = STRALLOC( buf );

   }
  if ( hunt_rate == 3 || hunt_rate == 4 )
   {
    set_char_color( AT_RED, ch );
    ch_printf( ch, "After waiting a long time for any animals... ... nothing shows up\r\n"); 
    act( AT_PLAIN, "$n sighs and looks disappointed", ch, NULL, NULL, TO_ROOM );
    return;
   }
  if ( hunt_rate == 5 )
   {
     prey = create_mobile( mob );
     prey->race = HUNT_DEER;
     STRFREE( prey->name );
     sprintf( buf, "a deer" );
     prey->name = STRALLOC( buf );
     STRFREE( prey->short_descr );
     prey->short_descr = STRALLOC( buf );
     STRFREE( prey->description );
     strcat( buf, " is frollicking in the forest here." );
     prey->long_descr = STRALLOC( buf );
   }
  if ( hunt_rate == 6 )
   {
     prey = create_mobile( mob );
     prey->race = HUNT_BEAR;
     STRFREE( prey->name );
     sprintf( buf, "a bear" );
     prey->name = STRALLOC( buf );
     STRFREE( prey->short_descr );
     prey->short_descr = STRALLOC( buf );
     STRFREE( prey->description );
     strcat( buf, " is neandering through the forest here." );
     prey->long_descr = STRALLOC( buf );
   }


   prey->powerlevel = 10;
   char_to_room( prey, ch->in_room );

   set_char_color( AT_GREEN, ch );
   ch_printf( ch, "Your patience has paid off, %s has appeared, better kill it!\r\n", prey->short_descr );
   act( AT_PLAIN, "$n eyes light up as their prey has finally arrived", ch, NULL, NULL, TO_ROOM );

   {
      long xpgain;

      xpgain =
         UMIN( 500,
               ( exp_level( ch->skill_level[ENGINEERING_ABILITY] + 1 ) -
                 exp_level( ch->skill_level[ENGINEERING_ABILITY] ) ) );
      gain_exp( ch, xpgain, ENGINEERING_ABILITY );
      ch_printf( ch, "You gain %d engineering experience.", xpgain );
   }
   learn_from_success( ch, gsn_hunt );
 return;
}

void do_gather_food( CHAR_DATA * ch, char *argument )
{
   char arg[MAX_INPUT_LENGTH];
   char buf[MAX_STRING_LENGTH];
   int level, schance, mvcost = 25;
   OBJ_DATA *obj;

   if ( !LEARNED( ch, gsn_gather_food) )   
    {
     set_char_color( AT_PLAIN, ch );
     send_to_char("Huh?\r\n", ch );
     return;
    }
   
   if ( !IS_MAP( ch ) )
    {
     set_char_color( AT_RED, ch );
     send_to_char( "You must be on the world map to gather food.\r\n", ch );
     return;
    }
   
   if ( ch->move < mvcost && !IS_ANDROID( ch ) )
    {
     set_char_color( AT_MAGIC, ch );
     send_to_char( "You are to tired to be foraging about...\r\n", ch );
     return;
    }

   switch ( ch->substate )
   {
      default:
         schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_gather_food] );
         if( number_percent(  ) < schance )
         {
            set_char_color( AT_GREEN, ch );
            send_to_char( "You start searching your surroundings for food.\r\n", ch );
            act( AT_PLAIN, "$n started poking around the area for food.", ch, NULL, NULL, TO_ROOM );
     
            if ( ch->move >= mvcost && !IS_ANDROID( ch ) )
             ch->move -= mvcost;

            add_timer( ch, TIMER_DO_FUN, 1, do_gather_food, 1 );
            ch->dest_buf = str_dup( arg );
            return;
         }

         set_char_color( AT_RED, ch );
         send_to_char( "You scratch your head in confusion, unsure where to start.\r\n", ch );
         learn_from_failure( ch, gsn_gather_food );
         return;

      case 1:
         if( !ch->dest_buf )
            return;
         strcpy( arg, ch->dest_buf );
         DISPOSE( ch->dest_buf );
         break;

      case SUB_TIMER_DO_ABORT:
         DISPOSE( ch->dest_buf );
         ch->substate = SUB_NONE;
         send_to_char( "&RYou are interupted and fail to finish your work.\r\n", ch );
         return;
   }

   ch->substate = SUB_NONE;

   level = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_gather_food] );
   schance = IS_NPC( ch ) ? ch->top_level : ( int )( ch->pcdata->learned[gsn_gather_food] );

   if( number_percent(  ) > schance * 2  )
   {
      set_char_color( AT_RED, ch );
      send_to_char( "You end your search and all you have discovered is that your still hungry.\r\n", ch );
      learn_from_failure( ch, gsn_gather_food );
      return;
   }

   obj = create_object( get_obj_index( OBJ_VNUM_FOOD ), 0 );;

  switch( ch->in_room->sector_type )
   {
    default:
     STRFREE( obj->name );
     sprintf( buf, "some berries" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     break;

    case SECT_WATER_SWIM:
     STRFREE( obj->name );
     sprintf( buf, "a mussel" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     break;

    case SECT_WATER_NOSWIM:
     STRFREE( obj->name );
     sprintf( buf, "some shrimp" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     break;

    case SECT_DESERT:
     STRFREE( obj->name );
     sprintf( buf, "a prickley pear cactus" );
     obj->name = STRALLOC( buf );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     break;
   }

   STRFREE( obj->description );
   strcat( buf, " was dropped here." );
   obj->description = STRALLOC( buf );
   obj->value[0] = level;
   obj->value[1] = level;
   obj->cost = level/2;

   obj = obj_to_char( obj, ch );

   set_char_color( AT_GREEN, ch );
   ch_printf( ch, "After much searching you have found %s\r\n", obj->short_descr );
   act( AT_PLAIN, "$n finishes their search of the area and holds up some food.", ch, NULL, NULL, TO_ROOM );

   {
      long xpgain;

      xpgain =
         UMIN( obj->cost * 100,
               ( exp_level( ch->skill_level[ENGINEERING_ABILITY] + 1 ) -
                 exp_level( ch->skill_level[ENGINEERING_ABILITY] ) ) );
      gain_exp( ch, xpgain, ENGINEERING_ABILITY );
      ch_printf( ch, "You gain %d engineering experience.", xpgain );
   }
   learn_from_success( ch, gsn_gather_food );
 return;
}

void do_skin_animal( CHAR_DATA * ch )
{
 return;
}

void do_drill_oil( CHAR_DATA * ch )
{
 return;
}

void do_make_plastic( CHAR_DATA * ch )
{
 return;
}

void do_forge_metal( CHAR_DATA * ch )
{
 return;
}

void generate_hide( CHAR_DATA * ch )
{
  OBJ_DATA *obj;
  char buf[MAX_INPUT_LENGTH];

 if ( !IS_NPC(ch ) )
    return;
 
 if ( !IS_PREY( ch ) )
    return;

 switch( ch->race )
  {
    default:
     break;

    case HUNT_RABBIT:
     obj = create_object( get_obj_index( OBJ_VNUM_RABBITHIDE ), 0 );
     STRFREE( obj->name );
     sprintf( buf, "the hide of %s", ch->name );
     obj->name = STRALLOC( buf );
     sprintf( buf, "the hide of %s", ch->short_descr );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );
   
     obj->value[0] = 3;
     obj->value[1] = 3;
     obj->cost = 10;
    break;   

    case HUNT_BOAR:
     obj = create_object( get_obj_index( OBJ_VNUM_BOARHIDE ), 0 );
     STRFREE( obj->name );
     sprintf( buf, "the hide of %s", ch->name );
     obj->name = STRALLOC( buf );
     sprintf( buf, "the hide of %s", ch->short_descr );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );
   
     obj->value[0] = 7;
     obj->value[1] = 7;
     obj->cost = 15;
    break;   

    case HUNT_DEER:
     obj = create_object( get_obj_index( OBJ_VNUM_DEERHIDE ), 0 );
     STRFREE( obj->name );
     sprintf( buf, "the hide of %s", ch->name );
     obj->name = STRALLOC( buf );
     sprintf( buf, "the hide of %s", ch->short_descr );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );
   
     obj->value[0] = 8;
     obj->value[1] = 8;
     obj->cost = 20;
    break;   

    case HUNT_BEAR:
     obj = create_object( get_obj_index( OBJ_VNUM_BEARHIDE ), 0 );
     STRFREE( obj->name );
     sprintf( buf, "the hide of %s", ch->name );
     obj->name = STRALLOC( buf );
     sprintf( buf, "the hide of %s", ch->short_descr );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );
   
     obj->value[0] = 10;
     obj->value[1] = 10;
     obj->cost = 300;
    break;   
  }

  obj = obj_to_char( obj, ch );
 return;
}
