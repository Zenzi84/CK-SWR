/*
 *                               Celestial Knights
 *                             Benjamin 'Tzu' Peters
 *                                   android.c
 *                    Module for android upgrades and affects
 */

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <math.h>
#include "mud.h"
#include "sha256.h"

/*
 * Upgrade DEFINEs are in mud.h
 */

/* build.c */
char *const i_flags[] = {
   "", "cpu", "reactor", "capacitor", "plating", "heat", "resistor",
   "circuit", "fuse", "r09", "r10", "r11", "r12", "r12",
   "r13", "r14", "r15", "r16", "r17", "r18", "r19", "r20",
   "r21", "22", "r23", "r24", "r25", "r26", "r27", "r28",
   "r29", "r31"
};

/* not used */
char *const install_locs[] = {
   "reactor", "cpu", "capacitor"
};

/* do_equipment */
char *const install_name[] = {
   "< R1              > ",
   "< CPU             > ",
   "< REACTOR         > ",
   "< CAPACITOR       > ",
   "< PLATING         > ",
   "< HEATSINK        > ",
   "< RESISTOR        > ",
   "< CIRCUIT BOARD   > ",
   "< FUSE            > "

};

/* displays upgrades in do_equipment */
void list_upgrades_to_char( CHAR_DATA *ch, OBJ_DATA *obj, int iWear )
  {
   send_to_char( "\r\n\r\n", ch );
   set_char_color( AT_BLOOD, ch );
   send_to_char( "Scanning upgrades... ...\r\n", ch );
   set_char_color( AT_OBJECT, ch );
   send_to_char( "\r\n", ch );

   for( iWear = 0; iWear < MAX_INSTALL; iWear++ )
      for( obj = ch->first_carrying; obj; obj = obj->next_content )
         if( obj->install_loc == iWear )
         {
          if ( !IS_UPGRADE( obj ) )
           continue;

            set_char_color( AT_RED, ch );           
            send_to_char( install_name[iWear], ch );
            ch_printf( ch, "%-25s", format_obj_to_char( obj, ch, TRUE ) );
            send_to_char( " ", ch );
            set_char_color( AT_BLOOD, ch );
            send_to_char( "[", ch );

               switch ( obj->install_flags )
               {
                  case ITEM_INSTALL_CPU:
                     ch_printf( ch, "PL Multi: %-1.2fx", GET_TRANS(ch ) );
                     break;
                  case ITEM_INSTALL_REACTOR:
                     ch_printf( ch, "PL: %s", num_punct_ld( ( obj->value[0] * obj->value[1] )  ) );
                     break;
                  case ITEM_INSTALL_CAPACITOR:
                     ch_printf( ch, "Cap: %s]", num_punct_ld( ( obj->value[0] * obj->value[1] ) ) );
                     break;
                  case ITEM_INSTALL_PLATING:
                     ch_printf( ch, "HP: %s", num_punct_ld( obj->value[0] ) );
                     break;
                  case ITEM_INSTALL_HEAT:
                     ch_printf( ch, "Heat: %s", num_punct_ld( obj->value[0] ) );
                     break;

                  default:
                     break;
               }

            set_char_color( AT_BLOOD, ch );
            send_to_char( " ]", ch );
            send_to_char( "\r\n", ch );
    }
   return;
  }

/* Applies values from upgrade to character */
void apply_upgrade( CHAR_DATA * ch, OBJ_DATA * obj )
{
 switch( obj->install_flags )
  {
   case ITEM_INSTALL_REACTOR:
    ch->powerlevel += ( obj->value[0] * obj->value[1] );
    break;
   case ITEM_INSTALL_CPU:
    GET_TRANS( ch ) = GET_TRANS(ch) + ( (double)obj->value[0] / 100 );
    break;
   case ITEM_INSTALL_CAPACITOR:
    ch->capacitor += ( obj->value[0] * obj->value[1] );
    break;
   case ITEM_INSTALL_PLATING:
    ch->max_hit     += obj->value[0];
    ch->hit     += obj->value[0];
    break;
   case ITEM_INSTALL_HEAT:
    ch->max_mana     += obj->value[0];
    ch->mana     += obj->value[0];
    break;
   case ITEM_INSTALL_RESISTOR:
    break;
   case ITEM_INSTALL_CIRCUIT:
    break;
   case ITEM_INSTALL_FUSE:
    break;
  }
 return;
}

void de_apply_upgrade( CHAR_DATA * ch, OBJ_DATA * obj )
{
 switch( obj->install_flags )
  {
   case ITEM_INSTALL_REACTOR:
    ch->powerlevel = ch->base_pl;
    break;
   case ITEM_INSTALL_CPU:
    GET_TRANS( ch ) = 1.0;
    break;
   case ITEM_INSTALL_CAPACITOR:
    ch->capacitor = 0;
    break;
   case ITEM_INSTALL_PLATING:
   if ( ch->hit >= ch->max_hit )
    ch->hit -= obj->value[0];
    ch->max_hit -= obj->value[0];
    break;
   case ITEM_INSTALL_HEAT:
   if ( ch->mana >= ch->max_mana )
    ch->mana -= obj->value[0];
    ch->max_mana -= obj->value[0];
    break;
   case ITEM_INSTALL_RESISTOR:
    break;
   case ITEM_INSTALL_CIRCUIT:
    break;
   case ITEM_INSTALL_FUSE:
    break;
  }
 return;
}

bool remove_obj_upg( CHAR_DATA * ch, int iWear, bool fReplace )
{
   OBJ_DATA *obj;

   if( ( obj = get_install_char( ch, iWear ) ) == NULL )
      return TRUE;

   if( !fReplace && ch->carry_number + get_obj_number( obj ) > can_carry_n( ch ) )
   {
      act( AT_PLAIN, "$d: you can't carry that many items.", ch, NULL, obj->name, TO_CHAR );
      return FALSE;
   }

   if( !fReplace )
      return FALSE;

   if( IS_OBJ_STAT( obj, ITEM_NOREMOVE ) )
   {
      act( AT_PLAIN, "You can't remove $p.", ch, obj, NULL, TO_CHAR );
      return FALSE;
   }

   unequip_char( ch, obj );

   act( AT_ACTION, "$n stops using $p.", ch, obj, NULL, TO_ROOM );
   act( AT_ACTION, "You stop using $p.", ch, obj, NULL, TO_CHAR );
   oprog_remove_trigger( ch, obj );
   return TRUE;
}

/*
 * Install one object.
 * Optional replacement of existing objects.
 */
void install_obj( CHAR_DATA * ch, OBJ_DATA * obj, bool fReplace, short wear_bit )
{
   char buf[MAX_STRING_LENGTH];
   short bit, tmp;

   separate_obj( obj );

 if ( !IS_UPGRADE( obj ) )
   return;

 if ( IS_UPGRADE(obj) )
  { 
   if ( !IS_ANDROID( ch ) )
   {
     send_to_char("Just where do you intend to put an upgrade part?", ch);
      return;
    }

   if( wear_bit > -1 )
   {
      bit = wear_bit;
      if( !CAN_INSTALL( obj, 1 << bit ) )
      {
         if( fReplace )
         {
            switch ( 1 << bit )
            {
               default:
                  sprintf( buf, "You cannot install that on your %s.\r\n", i_flags[bit] );
                  send_to_char( buf, ch );
            }
         }
         return;
      }
   }
   else
   {
      for( bit = -1, tmp = 1; tmp < 31; tmp++ )
      {
         if( CAN_INSTALL( obj, 1 << tmp ) )
         {
            bit = tmp;
            break;
         }
      }
   }

  switch ( 1 << bit )
   {
      case ITEM_INSTALL_REACTOR:
         if( !remove_obj_upg( ch, INSTALL_REACTOR,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p into $s reactor bank.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p into your reactor bank.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_REACTOR );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/
      case ITEM_INSTALL_CPU:
         if( !remove_obj_upg( ch, INSTALL_CPU,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p into $s cpu bank.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p into your cpu bank.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_CPU );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/
      case ITEM_INSTALL_CAPACITOR:
         if( !remove_obj_upg( ch, INSTALL_CAPACITOR,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p into $s capacitor bank.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p into your capacitor bank.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_CAPACITOR );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/
      case ITEM_INSTALL_PLATING:
         if( !remove_obj_upg( ch, INSTALL_PLATING,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p onto $s body.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p onto your body.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_PLATING );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/
      case ITEM_INSTALL_HEAT:
         if( !remove_obj_upg( ch, INSTALL_HEAT,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p into $s heatsink bank.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p into your heatsink bank.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_HEAT );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/
      case ITEM_INSTALL_RESISTOR:
         if( !remove_obj_upg( ch, INSTALL_RESISTOR,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p into $s resistor bank.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p into your resistor bank.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_RESISTOR );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/
      case ITEM_INSTALL_CIRCUIT:
         if( !remove_obj_upg( ch, INSTALL_CIRCUIT,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p into $s circuit bank.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p into your circuit bank.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_CIRCUIT );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/
      case ITEM_INSTALL_FUSE:
         if( !remove_obj_upg( ch, INSTALL_FUSE,  fReplace ) )
            return;
         if( !oprog_use_trigger( ch, obj, NULL, NULL, NULL ) )
         {
            if( !obj->action_desc || obj->action_desc[0] == '\0' )
            {
               act( AT_ACTION, "$n installs $p into $s fuse box.", ch, obj, NULL, TO_ROOM );
               act( AT_ACTION, "You install $p into your fuse bank.", ch, obj, NULL, TO_CHAR );
            }
            else
               actiondesc( ch, obj, NULL );
         }
         equip_char( ch, obj, INSTALL_FUSE );
         oprog_wear_trigger( ch, obj );
         return;
/***************************************************************************/

      default:
         bug( "install_obj: uknown/unused item_install bit %d", bit );
         if( fReplace )
            send_to_char( "You can't install that.\r\n", ch );
         return;
   }
  }
  return;
}

void do_install( CHAR_DATA * ch, char *argument )
{
   char arg1[MAX_INPUT_LENGTH];
   char arg2[MAX_INPUT_LENGTH];
   OBJ_DATA *obj;
   short wear_bit;

   argument = one_argument( argument, arg1 );
   argument = one_argument( argument, arg2 );
   if( ( !str_cmp( arg2, "on" ) || !str_cmp( arg2, "upon" ) || !str_cmp( arg2, "around" ) ) && argument[0] != '\0' )
      argument = one_argument( argument, arg2 );

   if( !IS_ANDROID( ch ) )
   {
      send_to_char( "You are not an android.\r\n", ch );
      return;
   }

   if( arg1[0] == '\0' )
   {
      send_to_char( "Install what?\r\n", ch );
      return;
   }

   if( ms_find_obj( ch ) )
      return;

   if( !str_cmp( arg1, "all" ) )
   {
      OBJ_DATA *obj_next;

      for( obj = ch->first_carrying; obj; obj = obj_next )
      {
         obj_next = obj->next_content;
     if ( !IS_UPGRADE(obj) )
         continue;
     if ( IS_UPGRADE(obj) )
         if( obj->install_loc == INSTALL_NONE )
            install_obj( ch, obj, FALSE, -1 );

      }
      return;
   }
   else
   {
      if( ( obj = get_obj_carry( ch, arg1 ) ) == NULL )
      {
         send_to_char( "You do not have that upgrade.\r\n", ch );
         return;
      }

     if ( !IS_UPGRADE(obj) )
      {
        act( AT_PLAIN, "That is not a upgrade part.", ch, NULL, NULL, TO_CHAR );
        return;;
      }

     if ( IS_UPGRADE(obj) )
      {
      if( arg2[0] != '\0' )
         wear_bit = get_iflag( arg2 );
      else
         wear_bit = -1;
      install_obj( ch, obj, TRUE, wear_bit );
    }
   }

   return;
}



void do_uninstall( CHAR_DATA * ch, char *argument )
{
   char arg[MAX_INPUT_LENGTH];
   OBJ_DATA *obj, *obj_next;


   one_argument( argument, arg );

   if( !IS_ANDROID( ch ) )
   {
      send_to_char( "You are not an android.\r\n", ch );
      return;
   }

   if( arg[0] == '\0' )
   {
      send_to_char( "Uninstall what?\r\n", ch );
      return;
   }

   if( ms_find_obj( ch ) )
      return;

   if( !str_cmp( arg, "all" ) )  /* SB Remove all */
   {
      for( obj = ch->first_carrying; obj != NULL; obj = obj_next )
      {
         obj_next = obj->next_content;
    if ( IS_UPGRADE( obj ) )
     {
         if( obj->install_loc != INSTALL_NONE  )
            remove_obj_upg( ch, obj->install_loc, TRUE );
      }
    }
      return;
   }

   if( ( obj = get_obj_wear( ch, arg ) ) == NULL )
   {
      send_to_char( "You are not using that item.\r\n", ch );
      return;

   }

  if ( !IS_UPGRADE( obj ) )
   {
      act( AT_PLAIN, "That is not a upgrade part.", ch, NULL, NULL, TO_CHAR );
      return;
   }
    
  if ( IS_UPGRADE( obj ) )
   if( ( obj_next = get_install_char( ch, obj->install_loc ) ) != obj )
   {
      act( AT_PLAIN, "You must remove $p first.", ch, obj_next, NULL, TO_CHAR );
      return;
   }

  if ( IS_UPGRADE( obj ) )
   remove_obj_upg( ch, obj->install_loc, TRUE );

   return;
}

/* Ki display for androids in prompt */
char *disp_heat( CHAR_DATA * ch , char *hbuf)
{
 
 if ( ch->mana == ( ch->max_mana ) )
  sprintf( hbuf, "                    ");    
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.95 ) )
  sprintf( hbuf, "&b|                   ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.90 ) )
  sprintf( hbuf, "&b||                  ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.85 ) )
  sprintf( hbuf, "&b||&B|                 ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.80 ) )
  sprintf( hbuf, "&b||&B||                ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.75 ) )
  sprintf( hbuf, "&b||&B||&c|               ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.70 ) )
  sprintf( hbuf, "&b||&B||&c||              ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.65 ) )
  sprintf( hbuf, "&b||&B||&c||&C|             ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.60 ) )
  sprintf( hbuf, "&b||&B||&c||&C||            ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.55 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|           ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.50 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G||          ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.45 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||         ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.40 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|        ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.35 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y||       ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.30 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|||      ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.25 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|||&r|     ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.20 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|||&r||    ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.15 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|||&r|||   ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.10 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|||&r|||&R|  ");
 else if ( ch->mana > ( (double)(ch->max_mana) * 0.05 ) )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|||&r|||&R|| ");
 else if ( ch->mana >= 0 )
  sprintf( hbuf, "&b||&B||&c||&C||&G|||&Y|||&r|||&R|||");

 return hbuf;
}

/* When NPC android dies, generate some random upgrades based on level. */
void generate_upgrade( CHAR_DATA * ch )
{
  OBJ_DATA *obj;
  char buf[MAX_INPUT_LENGTH];
  int drop_chance = 10;
  int upgrade = number_range( 1, 5 );
  int serial = number_range(10000, 99999);

 if ( !IS_NPC(ch ) )
    return;
 
 if ( number_percent( ) > drop_chance )
    return;

 switch( upgrade )
  {
   default: // Something went wrong...
   break;
  
   case 1:
    obj = create_object( get_obj_index( OBJ_VNUM_UPGRADE ), 0 );

     SET_BIT( obj->install_flags, ITEM_INSTALL_REACTOR );
     STRFREE( obj->name );
     sprintf( buf, "RR%d-%dx reactor core", serial, ch->top_level );
     obj->name = STRALLOC( buf );
     sprintf( buf, "a RR%d - %dx reactor core", serial, ch->top_level );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );

     obj->value[0] = sqrt( ( ch->base_pl / 125 ) );
     obj->value[1] = number_range( ( obj->value[0] * .75 ), ( obj->value[0] * 1.25 ) );
     obj->level = ch->top_level;

     obj->cost = ch->top_level * 100;

     obj = obj_to_char( obj, ch );
   break;

   case 2:
    obj = create_object( get_obj_index( OBJ_VNUM_UPGRADE ), 0 );

     SET_BIT( obj->install_flags, ITEM_INSTALL_CAPACITOR );
     STRFREE( obj->name );
     sprintf( buf, "RR%d-%dx capacitor", serial, ch->top_level );
     obj->name = STRALLOC( buf );
     sprintf( buf, "a RR%d - %dx capacitor", serial, ch->top_level );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );

     obj->value[0] = sqrt( ( ch->base_pl ) );
     obj->value[1] = number_range( ( obj->value[0] * 0.75 ), ( obj->value[0] * 1.25 ) );
     obj->level = ch->top_level;

     obj->cost = ch->top_level * 100;

     obj = obj_to_char( obj, ch );
   break;

   case 3:
    obj = create_object( get_obj_index( OBJ_VNUM_UPGRADE ), 0 );

     SET_BIT( obj->install_flags, ITEM_INSTALL_CPU );
     STRFREE( obj->name );
     sprintf( buf, "RR%d-%dx cpu chip", serial, ch->top_level );
     obj->name = STRALLOC( buf );
     sprintf( buf, "a RR%d - %dx cpu chip", serial, ch->top_level );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );

     obj->value[0] =  number_range( ch->top_level*.75, ch->top_level * 2 );
     obj->level = ch->top_level;

     obj->cost = ch->top_level * 125;

     obj = obj_to_char( obj, ch );
   break;

   case 4:
    obj = create_object( get_obj_index( OBJ_VNUM_UPGRADE ), 0 );

     SET_BIT( obj->install_flags, ITEM_INSTALL_PLATING );
     STRFREE( obj->name );
     sprintf( buf, "RR%d-%dx steel plating", serial, ch->top_level );
     obj->name = STRALLOC( buf );
     sprintf( buf, "a RR%d - %dx steel plating", serial, ch->top_level );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );

     obj->value[0] =  number_range( ch->top_level * 30, ch->top_level * 70 );
     obj->level = ch->top_level;

     obj->cost = ch->top_level * 75;

     obj = obj_to_char( obj, ch );
   break;

   case 5:
    obj = create_object( get_obj_index( OBJ_VNUM_UPGRADE ), 0 );

     SET_BIT( obj->install_flags, ITEM_INSTALL_HEAT );
     STRFREE( obj->name );
     sprintf( buf, "RR%d-%dx heatsink", serial, ch->top_level );
     obj->name = STRALLOC( buf );
     sprintf( buf, "a RR%d - %dx heatsink", serial, ch->top_level );
     STRFREE( obj->short_descr );
     obj->short_descr = STRALLOC( buf );
     STRFREE( obj->description );
     strcat( buf, " was dropped here." );
     obj->description = STRALLOC( buf );

     obj->value[0] =  number_range( ch->top_level * 30, ch->top_level * 70 );
     obj->level = ch->top_level;

     obj->cost = ch->top_level * 75;

     obj = obj_to_char( obj, ch );
   break;
  }

 return;
}
