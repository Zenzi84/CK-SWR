/****************************************************************************
 * [S]imulated [M]edieval [A]dventure multi[U]ser [G]ame      |   \\._.//   *
 * -----------------------------------------------------------|   (0...0)   *
 * SMAUG 1.4 (C) 1994, 1995, 1996, 1998  by Derek Snider      |    ).:.(    *
 * -----------------------------------------------------------|    {o o}    *
 * SMAUG code team: Thoric, Altrag, Blodkai, Narn, Haus,      |   / ' ' \   *
 * Scryn, Rennard, Swordbearer, Gorog, Grishnakh, Nivek,      |~'~.VxvxV.~'~*
 * Tricops and Fireblade                                      |             *
 * ------------------------------------------------------------------------ *
 * Merc 2.1 Diku Mud improvments copyright (C) 1992, 1993 by Michael        *
 * Chastain, Michael Quan, and Mitchell Tse.                                *
 * Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,          *
 * Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.     *
 * ------------------------------------------------------------------------ *
 *                         Client Compression Module                        *
 ****************************************************************************/

#include <zlib.h>

#define TELOPT_COMPRESS2 86
#define COMPRESS_BUF_SIZE MAX_STRING_LENGTH

extern char will_compress2_str[];
extern char start_compress2_str[];

bool compressStart( DESCRIPTOR_DATA * d );
bool compressEnd( DESCRIPTOR_DATA * d );

typedef struct mccp_data MCCP;

struct mccp_data
{
   z_stream *out_compress;
   unsigned char *out_compress_buf;
};
